# INTCF — grafo piloto

102 conceptos, 98 afirmaciones documentadas. Graphify proyecta 95 aristas: puede agrupar relaciones con los mismos extremos. Las afirmaciones y citas íntegras se conservan en data/knowledge.json.

Extracción limitada a 40 de 498 fragmentos; búsqueda documental disponible en los seis PDF.
