---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "40 g de óxido mercúrico (rojo ó amarillo) · mezcla de 32 ml de ácido nítrico y 15 ml de agua"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/40_g_de_xido_mercrico_rojo__amarillo__mezcla_de_32_ml_de_cido_ntrico_y_15_ml_de_agua
---

# 40 g de óxido mercúrico (rojo ó amarillo)

## Connections
- [[mezcla de 32 ml de ácido nítrico y 15 ml de agua]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/40_g_de_xido_mercrico_rojo__amarillo__mezcla_de_32_ml_de_cido_ntrico_y_15_ml_de_agua
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 40 g de óxido mercúrico (rojo ó amarillo) → mezcla de 32 ml de ácido nítrico y 15 ml de agua
Relación: se disuelve en · concepto conectado: [[mezcla de 32 ml de ácido nítrico y 15 ml de agua|mezcla de 32 ml de ácido nítrico y 15 ml de agua]]

> Disolver 40 g de óxido mercúrico (rojo ó amarillo) en una mezcla de 32 ml de ácido nítrico y 15 ml de agua.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
