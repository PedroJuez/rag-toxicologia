---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "glutetimida · valores de pH alcalinos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/glutetimida__valores_de_pH_alcalinos
---

# absorbancia a 240

## Connections
- [[glutetimida]] - `decrecerá notablemente después de 5 minutos a pH 11 si está presente la` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/glutetimida__valores_de_pH_alcalinos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbancia a 240 → glutetimida
Relación: decrecerá notablemente después de 5 minutos a pH 11 si está presente la · concepto conectado: [[glutetimida|glutetimida]]

> la absorbancia a 240 decrecerá notablemente después de 5 minutos a pH 11, si este compuesto está presente

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `7907371d844938d65322aafa652f0c78310928c5f526a40df1e48a9e4e2706fe`
Localizador: {"kind": "normalized_char_offsets", "start": 135225, "end": 137427}
