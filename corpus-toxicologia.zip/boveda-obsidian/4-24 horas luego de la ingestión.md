---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "método · posibilidad de que ocurran estas reacciones"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/mtodo__posibilidad_de_que_ocurran_estas_reacciones
---

# 4-24 horas luego de la ingestión

#graphify/concept #graphify/EXTRACTED #community/mtodo__posibilidad_de_que_ocurran_estas_reacciones
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### método → 4-24 horas luego de la ingestión
Relación: sólo es útil dentro de las · concepto conectado: [[método|método]]

> el método, sólo es útil dentro de las 4-24 horas luego de la ingestión

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b8e8f85f8d671745ee4c18e02fd07a41c4019660aee0172b71a4c8e150c68b22`
Localizador: {"kind": "normalized_char_offsets", "start": 316595, "end": 318414}
