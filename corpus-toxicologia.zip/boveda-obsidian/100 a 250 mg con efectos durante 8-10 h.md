---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "MDMA · Consumo crónico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/MDMA__Consumo_crnico
---

# 100 a 250 mg con efectos durante 8-10 h

#graphify/concept #graphify/EXTRACTED #community/MDMA__Consumo_crnico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Metilona → 100 a 250 mg con efectos durante 8-10 h
Relación: tiene dosis de · concepto conectado: [[Metilona|Metilona]]

> Metilona : dosis de 100 a 250 mg con efectos durante 8-10 h.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `c835b0ddf136f827ee396d4d014c7b0854922ca81efb49a065bf457255b17670`
Localizador: {"kind": "normalized_char_offsets", "start": 227900, "end": 230260}
