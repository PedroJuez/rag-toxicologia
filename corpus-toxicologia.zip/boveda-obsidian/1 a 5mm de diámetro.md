---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "granos · 1 a 5mm de diámetro"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/granos__1_a_5mm_de_dimetro
---

# 1 a 5mm de diámetro

#graphify/concept #graphify/EXTRACTED #community/granos__1_a_5mm_de_dimetro
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### granos → 1 a 5mm de diámetro
Relación: normalmente tienen · concepto conectado: [[granos|granos]]

> Los granos normalmente tienen 1 a 5mm de diámetro

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9c22ce90311445dd51c9933063b349e6ad28c9b28ed1d30036098586a5c16add`
Localizador: {"kind": "normalized_char_offsets", "start": 53713, "end": 56084}
