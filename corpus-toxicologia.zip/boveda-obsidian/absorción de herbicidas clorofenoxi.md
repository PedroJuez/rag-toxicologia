---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "absorción de herbicidas clorofenoxi · edema pulmonar"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorcin_de_herbicidas_clorofenoxi__edema_pulmonar
---

# absorción de herbicidas clorofenoxi

## Connections
- [[Coma]] - `produce` [EXTRACTED]
- [[arreflexia]] - `produce` [EXTRACTED]
- [[calambres musculares]] - `produce` [EXTRACTED]
- [[diarrea]] - `produce` [EXTRACTED]
- [[edema pulmonar]] - `produce` [EXTRACTED]
- [[muerte]] - `produce en casos severos` [EXTRACTED]
- [[vómitos]] - `produce` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorcin_de_herbicidas_clorofenoxi__edema_pulmonar
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorción de herbicidas clorofenoxi → vómitos
Relación: produce · concepto conectado: [[vómitos|vómitos]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → diarrea
Relación: produce · concepto conectado: [[diarrea|diarrea]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → arreflexia
Relación: produce · concepto conectado: [[arreflexia|arreflexia]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → calambres musculares
Relación: produce · concepto conectado: [[calambres musculares|calambres musculares]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → edema pulmonar
Relación: produce · concepto conectado: [[edema pulmonar|edema pulmonar]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → Coma
Relación: produce · concepto conectado: [[Coma|Coma]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}

### absorción de herbicidas clorofenoxi → muerte
Relación: produce en casos severos · concepto conectado: [[muerte|muerte]]

> La absorción de herbicidas clorofenoxi producen vómitos, diarrea, arreflexia, calambres musculares, edema pulmonar, coma y muerte en casos severos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}
