---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "34,64 g de sulfato de cobre · mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/3464_g_de_sulfato_de_cobre__mezcla_de_05_ml_de_cido_sulfrico_y_suficiente_agua_para_producir_500_ml
---

# 34,64 g de sulfato de cobre

## Connections
- [[mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/3464_g_de_sulfato_de_cobre__mezcla_de_05_ml_de_cido_sulfrico_y_suficiente_agua_para_producir_500_ml
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 34,64 g de sulfato de cobre → mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml
Relación: se disuelve en · concepto conectado: [[mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml|mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml]]

> Disolver 34,64 g de sulfato de cobre en una mezcla de 0,5 ml de ácido sulfúrico y suficiente agua para producir 500 ml

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
