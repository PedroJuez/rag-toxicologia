---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "mescalina · la sinsemilla"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/mescalina__la_sinsemilla
---

# 4-metilmetcatinona

## Connections
- [[mefedrona]] - `es denominada alternativamente como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/mescalina__la_sinsemilla
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 4-metilmetcatinona → mefedrona
Relación: es denominada alternativamente como · concepto conectado: [[mefedrona|mefedrona]]

> 4-metilmetcatinona (mefedrona)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `7bebe2f6977ad4987e633c30d7afc88cc204faef8a1b3bd17e15032894362490`
Localizador: {"kind": "normalized_char_offsets", "start": 225789, "end": 227900}
