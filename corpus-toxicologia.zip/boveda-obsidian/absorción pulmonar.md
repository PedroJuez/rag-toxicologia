---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "absorción pulmonar · diferentes variables"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorcin_pulmonar__diferentes_variables
---

# absorción pulmonar

## Connections
- [[diferentes variables]] - `depende de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorcin_pulmonar__diferentes_variables
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorción pulmonar → diferentes variables
Relación: depende de · concepto conectado: [[diferentes variables|diferentes variables]]

> absorción pulmonar, que depende de diferentes variables

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `69b928de09f0ed03ac67c3ed8f7506f88a0deeaacb7c08b0fa00daa40ea3dacb`
Localizador: {"kind": "normalized_char_offsets", "start": 149631, "end": 151960}
