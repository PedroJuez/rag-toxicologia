---
source_file: "d115aa88b694132d06236fc4806abbaecdf1b8b0184ed267d43c7dd39eb70fe6.md"
type: "concept"
community: "40 fichas · Este documento"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/40_fichas__Este_documento
---

# 16 fichas de resoluciones judiciales

#graphify/concept #graphify/EXTRACTED #community/40_fichas__Este_documento
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 40 fichas → 16 fichas de resoluciones judiciales
Relación: incluyen · concepto conectado: [[40 fichas|40 fichas]]

> 40 fichas, incluidas 16 fichas de resoluciones judiciales

Fuente: toxicologia-derecho-penal-espana-2026-09-14.md
Fragmento: `01ef56b8d9024c784c7f534ae583467c4cf2ba13d108e7574e1dcf750b9d849f`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 2386}
