---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "MDMA · Consumo crónico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/MDMA__Consumo_crnico
---

# 8 horas

#graphify/concept #graphify/EXTRACTED #community/MDMA__Consumo_crnico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### MDMA → 8 horas
Relación: tuvo un período de semidestingración en el plasma de · concepto conectado: [[MDMA|MDMA]]

> con un período de semidestingración en el plasma de 8 horas.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `dfc5f73e057ef576c791f0aaf088134fa8e18f95dd4ed39e713abef3d412b6e9`
Localizador: {"kind": "normalized_char_offsets", "start": 186281, "end": 188471}
