---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "6 - 7 días · fenprocoumon"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/6_-_7_das__fenprocoumon
---

# 6 - 7 días

#graphify/concept #graphify/EXTRACTED #community/6_-_7_das__fenprocoumon
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### fenprocoumon → 6 - 7 días
Relación: tiene una larga vida media en plasma de · concepto conectado: [[fenprocoumon|fenprocoumon]]

> El fenprocoumon y la warfarina tienen una larga vida media en plasma (6 - 7 días y 0,5 - 3 días respectivamente)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b0de90299bb4a731d3ad556044217ed4f49107e8f74851ae9c32f08fc4211f16`
Localizador: {"kind": "normalized_char_offsets", "start": 212296, "end": 214693}
