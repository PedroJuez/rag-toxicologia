---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "tetracloroetileno · ácido tricloroacético"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/tetracloroetileno__cido_tricloroactico
---

# 2,2,2-tricloroetanol

## Connections
- [[ácido tricloroacético]] - `se metaboliza a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/tetracloroetileno__cido_tricloroactico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1,1,1-TRICLOROETANO → 2,2,2-tricloroetanol
Relación: se metaboliza a · concepto conectado: [[1,1,1-TRICLOROETANO|1,1,1-TRICLOROETANO]]

> El 2% de una dosis absorbida de 1,1,1-tricloroetano se metaboliza a 2,2,2-tricloroetanol

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6a244cfdcddb27609d66e935c25470d0d170e81ee247a115730bf93326e0a849`
Localizador: {"kind": "normalized_char_offsets", "start": 346162, "end": 348152}

### 2,2,2-tricloroetanol → ácido tricloroacético
Relación: se metaboliza a · concepto conectado: [[ácido tricloroacético|ácido tricloroacético]]

> se metaboliza a 2,2,2-tricloroetanol y luego al ácido tricloroacético.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6a244cfdcddb27609d66e935c25470d0d170e81ee247a115730bf93326e0a849`
Localizador: {"kind": "normalized_char_offsets", "start": 346162, "end": 348152}

### 2,2,2-tricloroetanol → ácido tricloroacético
Relación: se metaboliza a · concepto conectado: [[ácido tricloroacético|ácido tricloroacético]]

> 2,2,2-tricloroetanol el que a su vez se metaboliza a ácido tricloroacético

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `721c08fed7c847c44590e507da9baecf5dc9abb9ca1a652a56c21ef2f977b9b9`
Localizador: {"kind": "normalized_char_offsets", "start": 242998, "end": 245276}
