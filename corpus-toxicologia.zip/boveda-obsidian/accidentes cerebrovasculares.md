---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "HSA o trombosis del seno venoso cerebral, infartos cerebrales · accidentes cerebrovasculares"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/HSA_o_trombosis_del_seno_venoso_cerebral_infartos_cerebrales__accidentes_cerebrovasculares
---

# accidentes cerebrovasculares

## Connections
- [[HSA o trombosis del seno venoso cerebral, infartos cerebrales]] - `incluyen` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/HSA_o_trombosis_del_seno_venoso_cerebral_infartos_cerebrales__accidentes_cerebrovasculares
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### accidentes cerebrovasculares → HSA o trombosis del seno venoso cerebral, infartos cerebrales
Relación: incluyen · concepto conectado: [[HSA o trombosis del seno venoso cerebral, infartos cerebrales|HSA o trombosis del seno venoso cerebral, infartos cerebrales]]

> accidentes cerebrovasculares (HSA o trombosis del seno venoso cerebral, infartos cerebrales)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `e62d73fe6381291223c85404d366d7b430836207afd3539229eb32b81e383970`
Localizador: {"kind": "normalized_char_offsets", "start": 200965, "end": 203360}
