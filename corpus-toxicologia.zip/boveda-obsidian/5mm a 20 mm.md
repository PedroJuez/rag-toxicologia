---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "5mm a 20 mm · El espesor de las tabletas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/5mm_a_20_mm__El_espesor_de_las_tabletas
---

# 5mm a 20 mm

#graphify/concept #graphify/EXTRACTED #community/5mm_a_20_mm__El_espesor_de_las_tabletas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### El espesor de las tabletas → 5mm a 20 mm
Relación: varía de · concepto conectado: [[El espesor de las tabletas|El espesor de las tabletas]]

> El espesor de las tabletas varía de 5mm a 20 mm

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9efa24200ecd8a1b28e7bfcd9ddc0ac4f9f6a59bb853795e5cd63507993cfae3`
Localizador: {"kind": "normalized_char_offsets", "start": 103245, "end": 105394}
