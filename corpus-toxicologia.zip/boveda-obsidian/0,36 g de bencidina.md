---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Reactivo piridina – bencidina · 0,36 g de bencidina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Reactivo_piridina__bencidina__036_g_de_bencidina
---

# 0,36 g de bencidina

#graphify/concept #graphify/EXTRACTED #community/Reactivo_piridina__bencidina__036_g_de_bencidina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Reactivo piridina – bencidina → 0,36 g de bencidina
Relación: requiere disolver · concepto conectado: [[Reactivo piridina – bencidina|Reactivo piridina – bencidina]]

> Reactivo piridina – bencidina**:** disolver 0,36 g de bencidina en 10 ml de HCl 0,5 N.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
