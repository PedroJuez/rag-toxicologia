---
source_file: "2c0b0b436fcf032b6a263da1da6f023834dd914373a6d3ca2c3617b7112d303c.md"
type: "concept"
community: "Art. 382 bis CP · Abandono del lugar del accidente por el conductor"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Art_382_bis_CP__Abandono_del_lugar_del_accidente_por_el_conductor
---

# Abandono del lugar del accidente por el conductor

#graphify/concept #graphify/EXTRACTED #community/Art_382_bis_CP__Abandono_del_lugar_del_accidente_por_el_conductor
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Art. 382 bis CP → Abandono del lugar del accidente por el conductor
Relación: tiene como supuesto vinculado · concepto conectado: [[Art. 382 bis CP|Art. 382 bis CP]]

> | **Art. 382 bis CP** | Abandono del lugar del accidente por el conductor. |

Fuente: guia_penal_espanola_drogas_muertes_jurisprudencia_unificada.md
Fragmento: `e65c63b95d4d4d25b69fa74a51c7bb1ccebef5ddf3e23c79ddcdaafd55db9172`
Localizador: {"kind": "normalized_char_offsets", "start": 8734, "end": 11134}
