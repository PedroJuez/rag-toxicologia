---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Coma · absorción de herbicidas clorofenoxi"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Coma__absorcin_de_herbicidas_clorofenoxi
---

# accidente cerebro-vascular

#graphify/concept #graphify/EXTRACTED #community/Coma__absorcin_de_herbicidas_clorofenoxi
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Coma → accidente cerebro-vascular
Relación: considerado como causa de · concepto conectado: [[Coma|Coma]]

> el coma como causa de un accidente cerebro-vascular

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b7b5ef6a5263edc2aa62a442d98845b9743f3b4898bb69abfcb6f732cc34aea4`
Localizador: {"kind": "normalized_char_offsets", "start": 16986, "end": 19375}
