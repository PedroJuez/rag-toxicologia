---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "desarrollo de fibrosis pulmonar progresiva · absorción de dosis bajas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/desarrollo_de_fibrosis_pulmonar_progresiva__absorcin_de_dosis_bajas
---

# absorción de dosis bajas

## Connections
- [[desarrollo de fibrosis pulmonar progresiva]] - `puede llevar al` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/desarrollo_de_fibrosis_pulmonar_progresiva__absorcin_de_dosis_bajas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorción de dosis bajas → desarrollo de fibrosis pulmonar progresiva
Relación: puede llevar al · concepto conectado: [[desarrollo de fibrosis pulmonar progresiva|desarrollo de fibrosis pulmonar progresiva]]

> La absorción de dosis bajas puede llevar al desarrollo de fibrosis pulmonar progresiva

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `4bfc8f986b5a1f39b28e9c1dbba83572290133f5fa5e532bb970c7d95baf6596`
Localizador: {"kind": "normalized_char_offsets", "start": 322680, "end": 324896}
