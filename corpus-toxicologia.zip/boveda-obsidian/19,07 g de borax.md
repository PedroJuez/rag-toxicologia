---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Agua · Ácido Perclórico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Agua__cido_Perclrico
---

# 19,07 g de borax

## Connections
- [[Agua]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Agua__cido_Perclrico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 19,07 g de borax → Agua
Relación: se disuelve en · concepto conectado: [[Agua|Agua]]

> Disolver 19,07 g de borax en suficiente agua para producir 1000 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6af27aa0bfb702e590bbd9b2403abe2de69fcc48aa14cb1947729335c1321a41`
Localizador: {"kind": "normalized_char_offsets", "start": 364173, "end": 366495}
