---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1 g de p-dimetilaminobenzaldehído · 100 ml de etanol"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_g_de_p-dimetilaminobenzaldehdo__100_ml_de_etanol
---

# 1 g de p-dimetilaminobenzaldehído

## Connections
- [[100 ml de etanol]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/1_g_de_p-dimetilaminobenzaldehdo__100_ml_de_etanol
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 g de p-dimetilaminobenzaldehído → 100 ml de etanol
Relación: se disuelve en · concepto conectado: [[100 ml de etanol|100 ml de etanol]]

> Disolver 1 g de p-dimetilaminobenzaldehído en 100 ml de etanol y agregar 10 ml de ácido clorhídrico.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
