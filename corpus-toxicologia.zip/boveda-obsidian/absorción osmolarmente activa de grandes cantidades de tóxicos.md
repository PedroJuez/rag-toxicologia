---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "absorción osmolarmente activa de grandes cantidades de tóxicos · aumentos grandes en la osmolaridad del plasma"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorcin_osmolarmente_activa_de_grandes_cantidades_de_txicos__aumentos_grandes_en_la_osmolaridad_del_plasma
---

# absorción osmolarmente activa de grandes cantidades de tóxicos

#graphify/concept #graphify/EXTRACTED #community/absorcin_osmolarmente_activa_de_grandes_cantidades_de_txicos__aumentos_grandes_en_la_osmolaridad_del_plasma
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### aumentos grandes en la osmolaridad del plasma → absorción osmolarmente activa de grandes cantidades de tóxicos
Relación: pueden deberse a · concepto conectado: [[aumentos grandes en la osmolaridad del plasma|aumentos grandes en la osmolaridad del plasma]]

> aumentos grandes en la osmolaridad del plasma pueden deberse a la absorción osmolarmente activa de grandes cantidades de tóxicos (sobre todo el metanol, etanol o isopropanol).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `e6f80c2b07b5bf18a853e6675090bac10f5f80dd202c2d1ed24564577f7c981a`
Localizador: {"kind": "normalized_char_offsets", "start": 25292, "end": 27641}
