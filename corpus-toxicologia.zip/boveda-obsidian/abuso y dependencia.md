---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "trastornos psiquiátricos derivados del consumo de cannabis · abuso y dependencia"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/trastornos_psiquitricos_derivados_del_consumo_de_cannabis__abuso_y_dependencia
---

# abuso y dependencia

#graphify/concept #graphify/EXTRACTED #community/trastornos_psiquitricos_derivados_del_consumo_de_cannabis__abuso_y_dependencia
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### trastornos psiquiátricos derivados del consumo de cannabis → abuso y dependencia
Relación: incluyen · concepto conectado: [[trastornos psiquiátricos derivados del consumo de cannabis|trastornos psiquiátricos derivados del consumo de cannabis]]

> trastornos psiquiátricos derivados del consumo de cannabis (abuso y dependencia)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `714dc2e4741096cdbacf26fcca2ac53efbd09b9ef440ec7b3a7834b087eb80ea`
Localizador: {"kind": "normalized_char_offsets", "start": 156649, "end": 158816}
