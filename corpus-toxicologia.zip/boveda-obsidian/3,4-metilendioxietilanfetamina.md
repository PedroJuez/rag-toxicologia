---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "productos análogos de la anfetamina y de la metanfetamina · 3,4-metilendioxietilanfetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/productos_anlogos_de_la_anfetamina_y_de_la_metanfetamina__34-metilendioxietilanfetamina
---

# 3,4-metilendioxietilanfetamina

## Connections
- [[productos análogos de la anfetamina y de la metanfetamina]] - `es un ejemplo de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/productos_anlogos_de_la_anfetamina_y_de_la_metanfetamina__34-metilendioxietilanfetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3,4-metilendioxietilanfetamina → productos análogos de la anfetamina y de la metanfetamina
Relación: es un ejemplo de · concepto conectado: [[productos análogos de la anfetamina y de la metanfetamina|productos análogos de la anfetamina y de la metanfetamina]]

> Se han sintetizado otros muchos productos análogos de la anfetamina y de la metanfetamina, algunos de los cuales se han distribuido ilícitamente en pequeña escala en distintos lugares; por ejemplo, la 3,4-metilendioxietilanfetamina y la *N,N*-dimetilanfetamina.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `a16d7facd34189e42dbfdaf6b471a247f3ad3bd5502b14c7d9e2fb83927f4155`
Localizador: {"kind": "normalized_char_offsets", "start": 184277, "end": 186281}
