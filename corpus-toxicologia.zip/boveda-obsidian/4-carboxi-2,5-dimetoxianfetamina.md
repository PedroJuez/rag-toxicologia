---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "DOM · STP"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/DOM__STP
---

# 4-carboxi-2,5-dimetoxianfetamina

#graphify/concept #graphify/EXTRACTED #community/DOM__STP
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### DOM → 4-carboxi-2,5-dimetoxianfetamina
Relación: tiene como metabolito en humanos a · concepto conectado: [[DOM|DOM]]

> |DOM|Humanos|DOM|4-carboxi-2,5-dimetoxianfetamina|148-150|

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `dfc5f73e057ef576c791f0aaf088134fa8e18f95dd4ed39e713abef3d412b6e9`
Localizador: {"kind": "normalized_char_offsets", "start": 186281, "end": 188471}
