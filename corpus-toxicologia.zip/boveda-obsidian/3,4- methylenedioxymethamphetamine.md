---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "MDMA · Consumo crónico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/MDMA__Consumo_crnico
---

# 3,4- methylenedioxymethamphetamine

## Connections
- [[MDMA]] - `es sinónimo de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/MDMA__Consumo_crnico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3,4- methylenedioxymethamphetamine → MDMA
Relación: es sinónimo de · concepto conectado: [[MDMA|MDMA]]

> 3,4- methylenedioxymethamphetamine (MDMA)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `5a1cdaddd707042eb08d451200409dec266acbb95499d9146b045edbc3bdcfca`
Localizador: {"kind": "normalized_char_offsets", "start": 232303, "end": 234542}
