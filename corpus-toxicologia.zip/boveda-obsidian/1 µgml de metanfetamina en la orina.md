---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "1 µg/ml de metanfetamina en la orina · umbral de detección"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_g/ml_de_metanfetamina_en_la_orina__umbral_de_deteccin
---

# 1 µg/ml de metanfetamina en la orina

#graphify/concept #graphify/EXTRACTED #community/1_g/ml_de_metanfetamina_en_la_orina__umbral_de_deteccin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### umbral de detección → 1 µg/ml de metanfetamina en la orina
Relación: es · concepto conectado: [[umbral de detección|umbral de detección]]

> El umbral de detección es 1 µg/ml de metanfetamina en la orina y la prueba se puede realizar en tres minutos.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `c27d086fc69b647f674330992ee6292931f05612cf4742c9a5d6081084ac166b`
Localizador: {"kind": "normalized_char_offsets", "start": 172931, "end": 175311}
