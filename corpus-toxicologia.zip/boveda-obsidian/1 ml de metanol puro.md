---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "ácido sulfúrico al 10% V/V · 1 ml de metanol puro"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/cido_sulfrico_al_10_V/V__1_ml_de_metanol_puro
---

# 1 ml de metanol puro

## Connections
- [[ácido sulfúrico al 10% VV]] - `llevar a 1 litro con` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/cido_sulfrico_al_10_V/V__1_ml_de_metanol_puro
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 ml de metanol puro → ácido sulfúrico al 10% V/V
Relación: llevar a 1 litro con · concepto conectado: [[ácido sulfúrico al 10% VV|ácido sulfúrico al 10% V/V]]

> Tomar 1 ml de metanol puro y llevar a 1 litro con ácido sulfúrico al 10% V/V.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3d1709e6b76c1a79dc2eb577a3101a52889d8eeb14da9a739ed5e2950c77cb45`
Localizador: {"kind": "normalized_char_offsets", "start": 279901, "end": 281924}
