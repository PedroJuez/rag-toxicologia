---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "1 cm de diámetro · bolitas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_cm_de_dimetro__bolitas
---

# 1 cm de diámetro

#graphify/concept #graphify/EXTRACTED #community/1_cm_de_dimetro__bolitas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### bolitas → 1 cm de diámetro
Relación: tienen dimensiones de · concepto conectado: [[bolitas|bolitas]]

> las bolitas (de 1 cm de diámetro)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9efa24200ecd8a1b28e7bfcd9ddc0ac4f9f6a59bb853795e5cd63507993cfae3`
Localizador: {"kind": "normalized_char_offsets", "start": 103245, "end": 105394}
