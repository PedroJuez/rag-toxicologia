---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "División de Barcelona comarques · A. Belén Gallo García"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Divisin_de_Barcelona_comarques__A_Beln_Gallo_Garca
---

# A. Belén Gallo García

## Connections
- [[División de Barcelona comarques]] - `es subdirectora de la` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Divisin_de_Barcelona_comarques__A_Beln_Gallo_Garca
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### A. Belén Gallo García → División de Barcelona comarques
Relación: es subdirectora de la · concepto conectado: [[División de Barcelona comarques|División de Barcelona comarques]]

> A. Belén Gallo García
> 3 Subdirectora de la División de Barcelona comarques.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `22b3bc33fffd2202e380fe4a380507890f46d391c92c04ecb60980cabc55bdbf`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 2031}
