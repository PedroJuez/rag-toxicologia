---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Solución de arsenito de sodio · 1g de As₂O₃"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Solucin_de_arsenito_de_sodio__1g_de_AsO
---

# 1g de As₂O₃

#graphify/concept #graphify/EXTRACTED #community/Solucin_de_arsenito_de_sodio__1g_de_AsO
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Solución de arsenito de sodio → 1g de As₂O₃
Relación: se prepara disolviendo · concepto conectado: [[Solución de arsenito de sodio|Solución de arsenito de sodio]]

> Solución de arsenito de sodio: disolver 1g de As₂O₃ en el mínimo volumen posible de solución de NaOH 2 N

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
