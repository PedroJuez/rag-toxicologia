---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Cannabidiol (CBD) · propiedades psicoactivas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cannabidiol_CBD__propiedades_psicoactivas
---

# abstinencia al THC

#graphify/concept #graphify/EXTRACTED #community/Cannabidiol_CBD__propiedades_psicoactivas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Cannabidiol (CBD) → abstinencia al THC
Relación: es útil para el tratamiento de · concepto conectado: [[Cannabidiol (CBD)|Cannabidiol (CBD)]]

> - <u>Cannabidiol</u> (CBD): no tiene propiedades psicoactivas. Es útil para reducir el dolor, vómitos, inflamación, glaucoma, controlar los ataques epilépticos, tratar ciertas enfermedades mentales e incluso para el tratamiento de la abstinencia al THC.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `3bf84c9b7d5d2aaefd795c22efd4b4eb74c4223b20b976aa2705eda0b3903402`
Localizador: {"kind": "normalized_char_offsets", "start": 145349, "end": 147243}
