---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1 g · un infante"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_g__un_infante
---

# 5 ml de homogenato de tejido

## Connections
- [[1 g]] - `es equivalente a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/1_g__un_infante
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 5 ml de homogenato de tejido → 1 g
Relación: es equivalente a · concepto conectado: [[1 g|1 g]]

> 5 ml de homogenato de tejido (equivalente a 1 g)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3e68d3c8a603dde4c80641d01107fdc69ae5d5a2452c0bed8dc04b31a1912309`
Localizador: {"kind": "normalized_char_offsets", "start": 275654, "end": 277772}
