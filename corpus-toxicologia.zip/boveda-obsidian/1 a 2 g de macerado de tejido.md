---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Sangre · muestreo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Sangre__muestreo
---

# 1 a 2 g de macerado de tejido

#graphify/concept #graphify/EXTRACTED #community/Sangre__muestreo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Sangre → 1 a 2 g de macerado de tejido
Relación: puede sustituirse por · concepto conectado: [[Sangre|Sangre]]

> utilizando en lugar de sangre 1 a 2 g de macerado de tejido

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
