---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "DOM y la DOB · 15 a 25 miligramos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/DOM_y_la_DOB__15_a_25_miligramos
---

# 15 a 25 miligramos

#graphify/concept #graphify/EXTRACTED #community/DOM_y_la_DOB__15_a_25_miligramos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### DOM y la DOB → 15 a 25 miligramos
Relación: se consumen por vía oral en dosis de · concepto conectado: [[DOM y la DOB|DOM y la DOB]]

> La DOM y la DOB se consumen por lo general por vía oral en dosis de 15 a 25 miligramos.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `a16d7facd34189e42dbfdaf6b471a247f3ad3bd5502b14c7d9e2fb83927f4155`
Localizador: {"kind": "normalized_char_offsets", "start": 184277, "end": 186281}
