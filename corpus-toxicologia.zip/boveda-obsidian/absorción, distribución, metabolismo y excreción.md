---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "toxicocinética · fenómenos que experimenta un xenobiótico en el cuerpo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/toxicocintica__fenmenos_que_experimenta_un_xenobitico_en_el_cuerpo
---

# absorción, distribución, metabolismo y excreción

#graphify/concept #graphify/EXTRACTED #community/toxicocintica__fenmenos_que_experimenta_un_xenobitico_en_el_cuerpo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### fenómenos que experimenta un xenobiótico en el cuerpo → absorción, distribución, metabolismo y excreción
Relación: se pueden resumir en · concepto conectado: [[fenómenos que experimenta un xenobiótico en el cuerpo|fenómenos que experimenta un xenobiótico en el cuerpo]]

> Los fenómenos que experimenta un xenobiótico en el cuerpo se pueden resumir en: absorción, distribución, metabolismo y excreción.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f78a5cad21f456678ea7a0ceb1315bdec7603bc717288d2aa640814a78e76af4`
Localizador: {"kind": "normalized_char_offsets", "start": 327692, "end": 330041}
