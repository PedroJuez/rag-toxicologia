---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "5 ml de la fase orgánica · filtro"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/5_ml_de_la_fase_orgnica__filtro
---

# 5 ml de la fase orgánica

#graphify/concept #graphify/EXTRACTED #community/5_ml_de_la_fase_orgnica__filtro
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### filtro → 5 ml de la fase orgánica
Relación: se lava con · concepto conectado: [[filtro|filtro]]

> lavar el filtro con 5 ml de la fase orgánica

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `8f6d7c86b8bcf9608bb6f9e40790ba8c2e38e7b2cdb1fe80d0442a87bb6a86ee`
Localizador: {"kind": "normalized_char_offsets", "start": 60400, "end": 62610}
