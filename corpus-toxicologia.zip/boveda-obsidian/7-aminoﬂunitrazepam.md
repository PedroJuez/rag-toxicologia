---
source_file: "bffa95dfb281355e9b484b266034f2d461d14324f48862c16e051513ac9af478.md"
type: "concept"
community: "KETAMINA · Metoxetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/KETAMINA__Metoxetamina
---

# 7-aminoﬂunitrazepam

## Connections
- [[Metabolito principal]] - `es` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/KETAMINA__Metoxetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 7-aminoﬂunitrazepam → Metabolito principal
Relación: es · concepto conectado: [[Metabolito principal|Metabolito principal]]

> Metabolito principal: 7-aminoﬂunitrazepam

Fuente: BASE DE CONOCIMIENTO TOXICOLÓGICA.pdf
Fragmento: `57ba7b8c132a105cdc0cb32f0b08e40f86b1815a04ac36f8a9163db4efc2ed14`
Localizador: {"kind": "normalized_char_offsets", "start": 2198, "end": 3381, "pdf_page": 3}
