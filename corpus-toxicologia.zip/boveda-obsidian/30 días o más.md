---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "consumo Frecuente / crónico · 30 días o más"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/consumo_Frecuente_/_crnico__30_das_o_ms
---

# 30 días o más

#graphify/concept #graphify/EXTRACTED #community/consumo_Frecuente_/_crnico__30_das_o_ms
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### consumo Frecuente / crónico → 30 días o más
Relación: tiene un tiempo de detección en orina de · concepto conectado: [[consumo Frecuente  crónico|consumo Frecuente / crónico]]

> Frecuente / crónico 30 días o más

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `6801a9cd1a8780abf42f895d167fc27bc37e1ab314377c1381db990943e7631a`
Localizador: {"kind": "normalized_char_offsets", "start": 167977, "end": 170253}
