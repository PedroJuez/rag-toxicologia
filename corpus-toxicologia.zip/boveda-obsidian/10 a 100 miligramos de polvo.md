---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "“raya” de cocaína · 10 a 100 miligramos de polvo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/raya_de_cocana__10_a_100_miligramos_de_polvo
---

# 10 a 100 miligramos de polvo

#graphify/concept #graphify/EXTRACTED #community/raya_de_cocana__10_a_100_miligramos_de_polvo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### “raya” de cocaína → 10 a 100 miligramos de polvo
Relación: contiene · concepto conectado: [[“raya” de cocaína|“raya” de cocaína]]

> Una “raya” de cocaína tiene normalmente 3 a 5 centímetros de longitud y contiene 10 a 100 miligramos de polvo.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `628eb130f6bf2cf9ad8b3291b875bcb00961b4ca4cf113fabc1d99bbc63cfb2e`
Localizador: {"kind": "normalized_char_offsets", "start": 133254, "end": 135626}
