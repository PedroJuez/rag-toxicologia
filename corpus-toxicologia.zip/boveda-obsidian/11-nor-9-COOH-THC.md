---
source_file: "d9bbc99393f878a02d48dc7923372b0485a2c142547eac8725aea930d645d5f2.md"
type: "concept"
community: "Cannabis · Cannabis Indica"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cannabis__Cannabis_Indica
---

# 11-nor-9-COOH-THC

#graphify/concept #graphify/EXTRACTED #community/Cannabis__Cannabis_Indica
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Cannabis → 11-nor-9-COOH-THC
Relación: tiene como metabolito principal · concepto conectado: [[Cannabis|Cannabis]]

> |Cannabis|11-nor-9-COOH-THC|3-30 días (orina)|

Fuente: Toxicología Etanol Drogas.pdf
Fragmento: `dd1706b85201992f2ac8a6c29e729e079fce9fd00be8025c4b33d39a3c50f47c`
Localizador: {"kind": "normalized_char_offsets", "start": 3875, "end": 6262}
