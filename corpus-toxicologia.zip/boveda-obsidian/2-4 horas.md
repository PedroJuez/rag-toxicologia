---
source_file: "bffa95dfb281355e9b484b266034f2d461d14324f48862c16e051513ac9af478.md"
type: "concept"
community: "Vida media de eliminación · tiempo necesario para que la concentración del xenobiótico se reduzca a la mitad"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Vida_media_de_eliminacin__tiempo_necesario_para_que_la_concentracin_del_xenobitico_se_reduzca_a_la_mitad
---

# 2-4 horas

#graphify/concept #graphify/EXTRACTED #community/Vida_media_de_eliminacin__tiempo_necesario_para_que_la_concentracin_del_xenobitico_se_reduzca_a_la_mitad
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Vida media de eliminación → 2-4 horas
Relación: es de · concepto conectado: [[Vida media de eliminación|Vida media de eliminación]]

> Vida media de eliminación: 2-4 horas

Fuente: BASE DE CONOCIMIENTO TOXICOLÓGICA.pdf
Fragmento: `5063c4e752a7ae8b22fb4b9d58c3c775132fcc8331348a7279590d860d49e93e`
Localizador: {"kind": "normalized_char_offsets", "start": 4692, "end": 5859, "pdf_page": 5}
