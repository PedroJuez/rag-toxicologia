---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1,34 ml de CO · 1 g de Hb"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/134_ml_de_CO__1_g_de_Hb
---

# 1 g de Hb

## Connections
- [[1,34 ml de CO]] - `fija` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/134_ml_de_CO__1_g_de_Hb
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 g de Hb → 1,34 ml de CO
Relación: fija · concepto conectado: [[1,34 ml de CO|1,34 ml de CO]]

> 1 g de Hb fija 1,34 ml de CO

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `18b51a20dbd287e58db0b08d552772b688745473375370ead6f0edf76d9ee993`
Localizador: {"kind": "normalized_char_offsets", "start": 294014, "end": 296174}
