---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Carbamazepina · 298-46-4"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Carbamazepina__298-46-4
---

# 5H-Dibenz[b,f]azepine-5-carboxamide

#graphify/concept #graphify/EXTRACTED #community/Carbamazepina__298-46-4
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Carbamazepina → 5H-Dibenz[b,f]azepine-5-carboxamide
Relación: tiene como sinónimo · concepto conectado: [[Carbamazepina|Carbamazepina]]

> Sinónimo: 5H-Dibenz[b,f]azepine-5-carboxamide Fórmula molecular: C₁₅H₁₂N₂O Peso molecular relativo: 236 Nº CAS: 298-46-4 pKa: 7 **Estructura Química**

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `1845139d7ab461a3ac7b49f02b344ba4bc0bed214f311ff6d2d0ba9a2937b5e1`
Localizador: {"kind": "normalized_char_offsets", "start": 177160, "end": 179455}
