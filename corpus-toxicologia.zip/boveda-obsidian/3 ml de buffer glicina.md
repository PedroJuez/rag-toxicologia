---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "viales de NAD -ADH · 3 ml de buffer glicina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/viales_de_NAD_-ADH__3_ml_de_buffer_glicina
---

# 3 ml de buffer glicina

#graphify/concept #graphify/EXTRACTED #community/viales_de_NAD_-ADH__3_ml_de_buffer_glicina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### viales de NAD -ADH → 3 ml de buffer glicina
Relación: se reconstituyen con · concepto conectado: [[viales de NAD -ADH|viales de NAD -ADH]]

> Reconstituir los viales de NAD -ADH con 3 ml de buffer glicina.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2299a4eb5dff036a494fa534d3fd813391291cfb6b45479a76ed16189febb47c`
Localizador: {"kind": "normalized_char_offsets", "start": 229828, "end": 232169}
