---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "16 ml de ácido sulfúrico concentrado · SO₄ H2 6N"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/16_ml_de_cido_sulfrico_concentrado__SO_H2_6N
---

# 16 ml de ácido sulfúrico concentrado

#graphify/concept #graphify/EXTRACTED #community/16_ml_de_cido_sulfrico_concentrado__SO_H2_6N
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### SO₄ H2 6N → 16 ml de ácido sulfúrico concentrado
Relación: contiene · concepto conectado: [[SO₄ H2 6N|SO₄ H2 6N]]

> SO₄ H2 6N:16 ml de ácido sulfúrico concentrado, llevar a 100 ml con agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
