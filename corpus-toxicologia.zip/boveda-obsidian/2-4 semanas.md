---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "consumo Habitual · 2-4 semanas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/consumo_Habitual__2-4_semanas
---

# 2-4 semanas

#graphify/concept #graphify/EXTRACTED #community/consumo_Habitual__2-4_semanas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### consumo Habitual → 2-4 semanas
Relación: tiene un tiempo de detección en orina de · concepto conectado: [[consumo Habitual|consumo Habitual]]

> Habitual 2-4 semanas

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `6801a9cd1a8780abf42f895d167fc27bc37e1ab314377c1381db990943e7631a`
Localizador: {"kind": "normalized_char_offsets", "start": 167977, "end": 170253}
