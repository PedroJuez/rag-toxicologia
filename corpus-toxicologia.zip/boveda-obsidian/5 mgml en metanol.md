---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "soluciones patrón · material de referencia de orina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/soluciones_patrn__material_de_referencia_de_orina
---

# 5 mg/ml en metanol

#graphify/concept #graphify/EXTRACTED #community/soluciones_patrn__material_de_referencia_de_orina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### soluciones patrón → 5 mg/ml en metanol
Relación: se hacen con una concentración de · concepto conectado: [[soluciones patrón|soluciones patrón]]

> Se hacen todas las soluciones patrón con una concentración de 5 mg/ml en metanol

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `71fa8f5495fcab341b5069706f6d8c5bdc2396d82711b16b6ae392f9a8cf6619`
Localizador: {"kind": "normalized_char_offsets", "start": 168587, "end": 170940}
