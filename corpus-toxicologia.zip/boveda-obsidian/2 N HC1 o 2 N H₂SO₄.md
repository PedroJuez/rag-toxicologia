---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "pH · 2 N HC1 o 2 N H₂SO₄"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/pH__2_N_HC1_o_2_N_HSO
---

# 2 N HC1 o 2 N H₂SO₄

#graphify/concept #graphify/EXTRACTED #community/pH__2_N_HC1_o_2_N_HSO
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### pH → 2 N HC1 o 2 N H₂SO₄
Relación: se ajusta con · concepto conectado: [[pH|pH]]

> se ajusta su pH a 2 con 2 N HC1 o 2 N H₂SO₄

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `203592cccc96c3cf217db325edf2817f8824f1444a30c7570827b0e9d294a4c1`
Localizador: {"kind": "normalized_char_offsets", "start": 114129, "end": 116384}
