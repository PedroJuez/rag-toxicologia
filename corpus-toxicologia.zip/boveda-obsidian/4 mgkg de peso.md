---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "dosis letal en un adulto · 4 mg/kg de peso"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/dosis_letal_en_un_adulto__4_mg/kg_de_peso
---

# 4 mg/kg de peso

#graphify/concept #graphify/EXTRACTED #community/dosis_letal_en_un_adulto__4_mg/kg_de_peso
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### dosis letal en un adulto → 4 mg/kg de peso
Relación: puede ser tan baja como · concepto conectado: [[dosis letal en un adulto|dosis letal en un adulto]]

> La dosis letal en un adulto puede ser tan baja como 4 mg/kg de peso.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `09c351e68e0755783d9799bd367eae7f884c1d80178dd84cfc77c58eee14daae`
Localizador: {"kind": "normalized_char_offsets", "start": 320800, "end": 322680}
