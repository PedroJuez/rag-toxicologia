---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "abuso del etanol · incremento en plasma de la actividad de la gamma-glutamiltransferasa"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abuso_del_etanol__incremento_en_plasma_de_la_actividad_de_la_gamma-glutamiltransferasa
---

# abuso del etanol

## Connections
- [[incremento en plasma de la actividad de la gamma-glutamiltransferasa]] - `está usualmente asociado al` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/abuso_del_etanol__incremento_en_plasma_de_la_actividad_de_la_gamma-glutamiltransferasa
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### abuso del etanol → incremento en plasma de la actividad de la gamma-glutamiltransferasa
Relación: está usualmente asociado al · concepto conectado: [[incremento en plasma de la actividad de la gamma-glutamiltransferasa|incremento en plasma de la actividad de la gamma-glutamiltransferasa]]

> El abuso del etanol está usualmente asociado al incremento en plasma de la actividad de la gamma-glutamiltransferasa.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b758dce083a064d3af9ccec002825b45cfeb3eaf1bc7be21fc1211ec4b6169f6`
Localizador: {"kind": "normalized_char_offsets", "start": 27641, "end": 29549}
