---
source_file: "bffa95dfb281355e9b484b266034f2d461d14324f48862c16e051513ac9af478.md"
type: "concept"
community: "Vida media de distribución · 7-15 minutos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Vida_media_de_distribucin__7-15_minutos
---

# 7-15 minutos

#graphify/concept #graphify/EXTRACTED #community/Vida_media_de_distribucin__7-15_minutos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Vida media de distribución → 7-15 minutos
Relación: es de · concepto conectado: [[Vida media de distribución|Vida media de distribución]]

> Vida media de distribución: 7-15 minutos

Fuente: BASE DE CONOCIMIENTO TOXICOLÓGICA.pdf
Fragmento: `c9f4d0e07c54c3ec71b954f683d6df49c0b4fdf0f96d70c5fe9c8669af676951`
Localizador: {"kind": "normalized_char_offsets", "start": 3381, "end": 4692, "pdf_page": 4}
