---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed · absorción de bromoxinil y loxinil"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/fatigas_irritabilidad_sudoracin_excesiva_hipertermia_taquicardia_vmitos_y_sed__absorcin_de_bromoxinil_y_loxinil
---

# absorción de bromoxinil y loxinil

## Connections
- [[fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed]] - `puede dar lugar a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/fatigas_irritabilidad_sudoracin_excesiva_hipertermia_taquicardia_vmitos_y_sed__absorcin_de_bromoxinil_y_loxinil
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorción de bromoxinil y loxinil → fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed
Relación: puede dar lugar a · concepto conectado: [[fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed|fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed]]

> La absorción de bromoxinil y loxinil puede dar lugar a fatigas, irritabilidad, sudoración excesiva, hipertermia, taquicardia, vómitos y sed

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fdc27094515fcbd1a124e0f9902a5e1f0ad10acb9a2790e1847014ed59286fe`
Localizador: {"kind": "normalized_char_offsets", "start": 245276, "end": 246484}
