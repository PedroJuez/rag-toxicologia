---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "decolorar · solución saturada de bisulfito"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/decolorar__solucin_saturada_de_bisulfito
---

# 1 gota de bisulfito de sodio

## Connections
- [[decolorar]] - `se adiciona para` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/decolorar__solucin_saturada_de_bisulfito
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 gota de bisulfito de sodio → decolorar
Relación: se adiciona para · concepto conectado: [[decolorar|decolorar]]

> adicionar 1 gota de bisulfito de sodio para decolorar.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3e68d3c8a603dde4c80641d01107fdc69ae5d5a2452c0bed8dc04b31a1912309`
Localizador: {"kind": "normalized_char_offsets", "start": 275654, "end": 277772}
