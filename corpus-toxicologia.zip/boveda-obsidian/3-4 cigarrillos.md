---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Dosis altas · 3-4 cigarrillos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Dosis_altas__3-4_cigarrillos
---

# 3-4 cigarrillos

## Connections
- [[Dosis altas]] - `se consideran` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Dosis_altas__3-4_cigarrillos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3-4 cigarrillos → Dosis altas
Relación: se consideran · concepto conectado: [[Dosis altas|Dosis altas]]

> Dosis altas se consideran 3-4 cigarrillos

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `69b928de09f0ed03ac67c3ed8f7506f88a0deeaacb7c08b0fa00daa40ea3dacb`
Localizador: {"kind": "normalized_char_offsets", "start": 149631, "end": 151960}
