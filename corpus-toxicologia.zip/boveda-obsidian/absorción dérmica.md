---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "pasta de coca · clorhidrato de cocaína"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/pasta_de_coca__clorhidrato_de_cocana
---

# absorción dérmica

#graphify/concept #graphify/EXTRACTED #community/pasta_de_coca__clorhidrato_de_cocana
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### intoxicación con nitrobenceno → absorción dérmica
Relación: puede producirse por · concepto conectado: [[intoxicación con nitrobenceno|intoxicación con nitrobenceno]]

> La intoxicación con nitrobenceno puede producirse por inhalación o por absorción dérmica

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `0938bda6489298477c1fd72d408e22f2feb846bb99c16ca205cae7075642f475`
Localizador: {"kind": "normalized_char_offsets", "start": 307898, "end": 310286}
