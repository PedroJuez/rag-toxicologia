---
source_file: "d115aa88b694132d06236fc4806abbaecdf1b8b0184ed267d43c7dd39eb70fe6.md"
type: "concept"
community: "40 fichas · Este documento"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/40_fichas__Este_documento
---

# 40 fichas

## Connections
- [[16 fichas de resoluciones judiciales]] - `incluyen` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/40_fichas__Este_documento
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Este documento → 40 fichas
Relación: reúne · concepto conectado: [[Este documento|Este documento]]

> Este documento reúne 40 fichas

Fuente: toxicologia-derecho-penal-espana-2026-09-14.md
Fragmento: `01ef56b8d9024c784c7f534ae583467c4cf2ba13d108e7574e1dcf750b9d849f`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 2386}

### 40 fichas → 16 fichas de resoluciones judiciales
Relación: incluyen · concepto conectado: [[16 fichas de resoluciones judiciales|16 fichas de resoluciones judiciales]]

> 40 fichas, incluidas 16 fichas de resoluciones judiciales

Fuente: toxicologia-derecho-penal-espana-2026-09-14.md
Fragmento: `01ef56b8d9024c784c7f534ae583467c4cf2ba13d108e7574e1dcf750b9d849f`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 2386}
