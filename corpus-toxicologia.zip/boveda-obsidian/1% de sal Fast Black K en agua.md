---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "solución A · reactivo de Dragendorff"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/solucin_A__reactivo_de_Dragendorff
---

# 1% de sal Fast Black K en agua

#graphify/concept #graphify/EXTRACTED #community/solucin_A__reactivo_de_Dragendorff
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### solución A → 1% de sal Fast Black K en agua
Relación: consiste en · concepto conectado: [[solución A|solución A]]

> Solución A: 1% de sal Fast Black K en agua

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `0d688ab6a1df6719c0b9d2bfb0c44add5294b2a0993a80157cd7c34349d6e071`
Localizador: {"kind": "normalized_char_offsets", "start": 170940, "end": 172931}
