---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "residuo · 0,1 ml de metanol o metanol-cloroformo (9:1)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
---

# 50 µl de acetato de etilo

#graphify/concept #graphify/EXTRACTED #community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### residuo → 50 µl de acetato de etilo
Relación: se reconstituye con · concepto conectado: [[residuo|residuo]]

> reconstituir el residuo con 50 µl de acetato de etilo

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `771d5af39fb995f6be599a322cd0a15ddf506325b2dc98483f3cb73b6cd57787`
Localizador: {"kind": "normalized_char_offsets", "start": 69273, "end": 71609}

### residuo → 50 µl de acetato de etilo
Relación: se reconstituye con · concepto conectado: [[residuo|residuo]]

> Reconstituir el residuo con 50 µl de acetato de etilo.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `55a39933c436426e3703a8528c4fd0cfb9bf64e1c545f3e568f002baf6fe54fe`
Localizador: {"kind": "normalized_char_offsets", "start": 78691, "end": 80493}
