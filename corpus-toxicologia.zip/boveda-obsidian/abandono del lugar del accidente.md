---
source_file: "d115aa88b694132d06236fc4806abbaecdf1b8b0184ed267d43c7dd39eb70fe6.md"
type: "concept"
community: "abandono del lugar del accidente · 382 bis"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abandono_del_lugar_del_accidente__382_bis
---

# abandono del lugar del accidente

#graphify/concept #graphify/EXTRACTED #community/abandono_del_lugar_del_accidente__382_bis
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 382 bis → abandono del lugar del accidente
Relación: conecta con · concepto conectado: [[382 bis|382 bis]]

> 382 bis, abandono del lugar del accidente

Fuente: toxicologia-derecho-penal-espana-2026-09-14.md
Fragmento: `3798872df8d4f496da9801e3ba9b04ee62cf3853be096efb11cd9001a1a2bdd4`
Localizador: {"kind": "normalized_char_offsets", "start": 11527, "end": 13899}
