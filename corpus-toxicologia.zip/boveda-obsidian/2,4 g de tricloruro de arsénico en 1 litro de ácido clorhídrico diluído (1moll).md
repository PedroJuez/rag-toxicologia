---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "concentración de arsénico de 1 g/l · 2,4 g de tricloruro de arsénico en 1 litro de ácido clorhídrico diluído (1mol/l)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/concentracin_de_arsnico_de_1_g/l__24_g_de_tricloruro_de_arsnico_en_1_litro_de_cido_clorhdrico_diludo_1mol/l
---

# 2,4 g de tricloruro de arsénico en 1 litro de ácido clorhídrico diluído (1mol/l)

## Connections
- [[concentración de arsénico de 1 gl]] - `da una solución con` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/concentracin_de_arsnico_de_1_g/l__24_g_de_tricloruro_de_arsnico_en_1_litro_de_cido_clorhdrico_diludo_1mol/l
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 2,4 g de tricloruro de arsénico en 1 litro de ácido clorhídrico diluído (1mol/l) → concentración de arsénico de 1 g/l
Relación: da una solución con · concepto conectado: [[concentración de arsénico de 1 gl|concentración de arsénico de 1 g/l]]

> Disolver 2,4 g de tricloruro de arsénico en 1 litro de ácido clorhídrico diluído (1mol/l); esto da una solución que contiene una concentración de arsénico de 1 g/l.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `c0778b8f5c9a88a630e6fc9e9f7d71c995c8840637239e9d6f503782190e9c10`
Localizador: {"kind": "normalized_char_offsets", "start": 117925, "end": 120194}
