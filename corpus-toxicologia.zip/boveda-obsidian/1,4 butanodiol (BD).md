---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "GHB · la bhe"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/GHB__la_bhe
---

# 1,4 butanodiol (BD)

#graphify/concept #graphify/EXTRACTED #community/GHB__la_bhe
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### GHB → 1,4 butanodiol (BD)
Relación: se sintetiza in vivo a partir del consumo de · concepto conectado: [[GHB|GHB]]

> Es una sustancia fiscalizada, pero se sintetiza GHB *in vivo* a partir del consumo de gammabutirolactona (GBL) y el 1,4 butanodiol (BD), sustancias legales, que están presentes en productos de limpieza, cosmética, disolventes, entre otros.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `e1415e46d2dad4363ca2f18671e91d0553260aa7b266194cc62a1a522d1f7a73`
Localizador: {"kind": "normalized_char_offsets", "start": 245442, "end": 247674}
