---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "CLAR · lidocaína"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/CLAR__lidocana
---

# 1,5 ml/min

#graphify/concept #graphify/EXTRACTED #community/CLAR__lidocana
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Método A → 1,5 ml/min
Relación: tiene caudal de · concepto conectado: [[Método A|Método A]]

> Caudal: 1,5 ml/min

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `6009669f2db415af7d597b20308fd64df8e22d3baa711ad4f69cea40cfc74061`
Localizador: {"kind": "normalized_char_offsets", "start": 124903, "end": 127170}
