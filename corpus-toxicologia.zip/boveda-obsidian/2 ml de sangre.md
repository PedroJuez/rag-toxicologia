---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "compartimiento externo · 0,5 ml de SO₄H26N"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/compartimiento_externo__05_ml_de_SOH26N
---

# 2 ml de sangre

#graphify/concept #graphify/EXTRACTED #community/compartimiento_externo__05_ml_de_SOH26N
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### compartimiento externo → 2 ml de sangre
Relación: recibe · concepto conectado: [[compartimiento externo|compartimiento externo]]

> en el compartimiento externo 2 ml de sangre

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
