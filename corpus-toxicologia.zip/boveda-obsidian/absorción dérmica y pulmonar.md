---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "intoxicación aguda · absorción dérmica y pulmonar"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/intoxicacin_aguda__absorcin_drmica_y_pulmonar
---

# absorción dérmica y pulmonar

#graphify/concept #graphify/EXTRACTED #community/intoxicacin_aguda__absorcin_drmica_y_pulmonar
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### intoxicación aguda → absorción dérmica y pulmonar
Relación: puede ser por · concepto conectado: [[intoxicación aguda|intoxicación aguda]]

> La intoxicación aguda puede ser por absorción dérmica y pulmonar.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `85258ffd2e50e77111e371b23bfcdbee4944af0e664a76c40103074af055dd72`
Localizador: {"kind": "normalized_char_offsets", "start": 324896, "end": 326881}
