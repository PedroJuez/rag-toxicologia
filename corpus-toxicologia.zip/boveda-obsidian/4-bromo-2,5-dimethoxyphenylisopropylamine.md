---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "4-bromo-2,5-dimethoxyphenylisopropylamine · psychodysleptic"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/4-bromo-25-dimethoxyphenylisopropylamine__psychodysleptic
---

# 4-bromo-2,5-dimethoxyphenylisopropylamine

## Connections
- [[psychodysleptic]] - `es` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/4-bromo-25-dimethoxyphenylisopropylamine__psychodysleptic
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 4-bromo-2,5-dimethoxyphenylisopropylamine → psychodysleptic
Relación: es · concepto conectado: [[psychodysleptic|psychodysleptic]]

> psychodysleptic 4-bromo-2,5-dimethoxyphenylisopropylamine

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `5a1cdaddd707042eb08d451200409dec266acbb95499d9146b045edbc3bdcfca`
Localizador: {"kind": "normalized_char_offsets", "start": 232303, "end": 234542}
