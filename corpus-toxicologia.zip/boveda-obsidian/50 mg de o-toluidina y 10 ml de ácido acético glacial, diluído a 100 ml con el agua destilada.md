---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Reactivo de o-Toluidina · 50 mg de o-toluidina y 10 ml de ácido acético glacial, diluído a 100 ml con el agua destilada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Reactivo_de_o-Toluidina__50_mg_de_o-toluidina_y_10_ml_de_cido_actico_glacial_diludo_a_100_ml_con_el_agua_destilada
---

# 50 mg de o-toluidina y 10 ml de ácido acético glacial, diluído a 100 ml con el agua destilada

#graphify/concept #graphify/EXTRACTED #community/Reactivo_de_o-Toluidina__50_mg_de_o-toluidina_y_10_ml_de_cido_actico_glacial_diludo_a_100_ml_con_el_agua_destilada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Reactivo de o-Toluidina → 50 mg de o-toluidina y 10 ml de ácido acético glacial, diluído a 100 ml con el agua destilada
Relación: se obtiene al mezclar · concepto conectado: [[Reactivo de o-Toluidina|Reactivo de o-Toluidina]]

> Reactivo de o-Toluidina. Mezclar 50 mg de o-toluidina y 10 ml de ácido acético glacial, diluído a 100 ml con el agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b17422d6b1dbfbcb88b49586f4157e3c2875b7ef30eb1c469b2a00372efa7aa8`
Localizador: {"kind": "normalized_char_offsets", "start": 240714, "end": 242998}
