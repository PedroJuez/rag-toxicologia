---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "ergotamina · AL-LAD"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/ergotamina__AL-LAD
---

# 1P-LSD

## Connections
- [[ergotamina]] - `es un derivado sintetizado de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/ergotamina__AL-LAD
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1P-LSD → ergotamina
Relación: es un derivado sintetizado de · concepto conectado: [[ergotamina|ergotamina]]

> Del mismo modo, se han sintetizado otros derivados de la ergotamina, algunos de los cuales no están fiscalizados y que tienen una estructura y efectos similares al LSD (LSZ, AL-LAD, 1P-LSD, ALD-52).

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `30a414f9a12563168770c7b57889685c0fcc6b7fa5051a17f60844b4f30c0d0d`
Localizador: {"kind": "normalized_char_offsets", "start": 265372, "end": 267646}
