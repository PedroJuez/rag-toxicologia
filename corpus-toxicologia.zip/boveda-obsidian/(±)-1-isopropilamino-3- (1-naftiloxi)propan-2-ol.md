---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "PROPRANOLOL · Síntomas y signos simpaticomiméticos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/PROPRANOLOL__Sntomas_y_signos_simpaticomimticos
---

# (±)-1-isopropilamino-3- (1-naftiloxi)propan-2-ol

#graphify/concept #graphify/EXTRACTED #community/PROPRANOLOL__Sntomas_y_signos_simpaticomimticos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### PROPRANOLOL → (±)-1-isopropilamino-3- (1-naftiloxi)propan-2-ol
Relación: tiene sinónimo · concepto conectado: [[PROPRANOLOL|PROPRANOLOL]]

> Sinónimos: (±)-1-isopropilamino-3- (1-naftiloxi)propan-2-ol

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `e557e8b517f1cd180ef7ef6598c66b8a2a87dbcf8f1ee6e0ff0a2c9fe23396f9`
Localizador: {"kind": "normalized_char_offsets", "start": 333452, "end": 335765}
