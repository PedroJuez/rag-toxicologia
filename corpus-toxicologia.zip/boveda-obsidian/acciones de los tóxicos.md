---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "profesional bioquímico · cinética en el organismo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/profesional_bioqumico__cintica_en_el_organismo
---

# acciones de los tóxicos

#graphify/concept #graphify/EXTRACTED #community/profesional_bioqumico__cintica_en_el_organismo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### profesional bioquímico → acciones de los tóxicos
Relación: debería tener en cuenta · concepto conectado: [[profesional bioquímico|profesional bioquímico]]

> Para un correcto estudio de toda situación, el profesional bioquímico debería tener en cuenta no sólo las acciones de los tóxicos sino la cinética en el organismo es decir: absorción, distribución, metabolismo y excreción.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3e38c40d46d2882f006b46905c95ca8c5fbc1c87860bc56afb364033c49d9c60`
Localizador: {"kind": "normalized_char_offsets", "start": 13502, "end": 15129}
