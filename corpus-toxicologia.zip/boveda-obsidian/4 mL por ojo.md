---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Humor vítreo · Fluido oral"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Humor_vtreo__Fluido_oral
---

# 4 mL por ojo

#graphify/concept #graphify/EXTRACTED #community/Humor_vtreo__Fluido_oral
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Humor vítreo → 4 mL por ojo
Relación: se encuentra en una cantidad aproximada de · concepto conectado: [[Humor vítreo|Humor vítreo]]

> Se encuentra en una cantidad aproximada de 4 mL por ojo.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `5c537959640443a0bbbe019981412facbf2160367b350a59a65165b98444b0c5`
Localizador: {"kind": "normalized_char_offsets", "start": 22748, "end": 24949}
