---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "anticoagulantes de primera generación · 4-hidroxi-cumarina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/anticoagulantes_de_primera_generacin__4-hidroxi-cumarina
---

# 4-hidroxi-cumarina

#graphify/concept #graphify/EXTRACTED #community/anticoagulantes_de_primera_generacin__4-hidroxi-cumarina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### anticoagulantes de primera generación → 4-hidroxi-cumarina
Relación: son sustancias derivadas de · concepto conectado: [[anticoagulantes de primera generación|anticoagulantes de primera generación]]

> Son sustancias derivadas de la 4-hidroxi-cumarina (anticoagulantes de primera generación)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `518040e390d5afded824d745af31def603efaf6a5fe89b9b2d36041ac65ad5d5`
Localizador: {"kind": "normalized_char_offsets", "start": 210142, "end": 212296}
