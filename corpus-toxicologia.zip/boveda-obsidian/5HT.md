---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "serotonina · moléculas que se encuentran de forma natural"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/serotonina__molculas_que_se_encuentran_de_forma_natural
---

# 5HT

## Connections
- [[serotonina]] - `significa` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/serotonina__molculas_que_se_encuentran_de_forma_natural
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 5HT → serotonina
Relación: significa · concepto conectado: [[serotonina|serotonina]]

> 8 alc. % vol. ” o “ **–** porcentaje de etanol presente en la bebida ºC **–** grados Celsius αPVP **–** alfa-pirrolidinpentiodenona 5HT **–** serotonina 6-MAM **–** 6-monoacetilmorfina aC **–** antes de Cristo ADH **–** alcohol deshidrogenasa / hormona antidiurética AINES **–** antiinflamatorios no esteroideos ALDH **–** aldehído deshidrogenasa ATC **–** antidepresivo tricíclico bd **–** biodisponibilidad BD **–** 1,4 butanodiol bhe **–** barrera hematoencefálica bpl **–** barrera placentaria BZP **–** benzilpiperazina CB **–** receptor cannabinoide CBN **–** cannabinol CBD **–** cannabidiol CEDIA ® **–** enzimoinmunoensayo homogéneo cm **–** centímetro Cmax **–** pico de concentración máxima CYP **–** citocromo p450 dL **–** decilitro DRI ® **–** enzimoinmunoensayo homogéneo DSM **–** Diagnostic and Statistical Manual of Mental Disorders EDDP **–** 2-etilideno-1,5-dimetil-3,3-difenilpirrodilidina EDTA **–** ácido etilendiamintetracético EMDP **–** 2-etil-5-metil-3,3-difenil-1-pirrolina EME **–** ecgonina metil éster etc **–** etcétera EtG **–** etilglucurónido EUA **–** Estados Unidos de América ej **–** ejemplo ev **–** endovenoso, endovenosa FAEES **–** ésteres etílicos de los ácidos grasos FID **–** detector de ionización de llama fig **–** figura g **–** gramo

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `2d014dd8c83a2715a4c7bd408cfba4ff4df902db4ef0ddf281886c2f220e5205`
Localizador: {"kind": "normalized_char_offsets", "start": 8237, "end": 9524}
