---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "glucurónidos · 3,4-dihidroximetanfetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/glucurnidos__34-dihidroximetanfetamina
---

# 3,4-dihidroximetanfetamina

## Connections
- [[glucurónidos]] - `es excretada como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/glucurnidos__34-dihidroximetanfetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3,4-dihidroximetanfetamina → glucurónidos
Relación: es excretada como · concepto conectado: [[glucurónidos|glucurónidos]]

> Los principales metabolitos de la orina fueron la 4-hidroxi-3-metoximetanfetamina y la 3,4-dihidroximetanfetamina, ambas excretadas como glucurónidos

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `dfc5f73e057ef576c791f0aaf088134fa8e18f95dd4ed39e713abef3d412b6e9`
Localizador: {"kind": "normalized_char_offsets", "start": 186281, "end": 188471}
