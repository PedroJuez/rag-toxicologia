---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Cannabis · Cannabis Indica"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cannabis__Cannabis_Indica
---

# absorción y el aclaramiento de sustancias consumidas concomitantemente

#graphify/concept #graphify/EXTRACTED #community/Cannabis__Cannabis_Indica
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Cannabis → absorción y el aclaramiento de sustancias consumidas concomitantemente
Relación: ralentiza · concepto conectado: [[Cannabis|Cannabis]]

> -La absorción y el aclaramiento de sustancias consumidas concomitantemente con el cannabis se ven ralentizadas

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `4bc77a841b981111b77e72cb17847bc588bcdac3571c3f2825ef35b676b85d20`
Localizador: {"kind": "normalized_char_offsets", "start": 163386, "end": 165709}
