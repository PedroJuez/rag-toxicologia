---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "Cocaine, Marihuana and Designer Drugs: Chemistry, Pharmacology and Behaviour · A. Walker y G. Barnett"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cocaine_Marihuana_and_Designer_Drugs_Chemistry_Pharmacology_and_Behaviour__A_Walker_y_G_Barnett
---

# A. Walker y G. Barnett

## Connections
- [[Cocaine, Marihuana and Designer Drugs Chemistry, Pharmacology and Behaviour]] - `son editores de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cocaine_Marihuana_and_Designer_Drugs_Chemistry_Pharmacology_and_Behaviour__A_Walker_y_G_Barnett
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### A. Walker y G. Barnett → Cocaine, Marihuana and Designer Drugs: Chemistry, Pharmacology and Behaviour
Relación: son editores de · concepto conectado: [[Cocaine, Marihuana and Designer Drugs Chemistry, Pharmacology and Behaviour|Cocaine, Marihuana and Designer Drugs: Chemistry, Pharmacology and Behaviour]]

> A. Walker y G. Barnett (Eds.) Cocaine, Marihuana and Designer Drugs: Chemistry, Pharmacology and Behaviour

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `ff8543a44cc06445acf0d215fdc9ec101992c821a1fae986a116d00f427857d9`
Localizador: {"kind": "normalized_char_offsets", "start": 225258, "end": 227645}
