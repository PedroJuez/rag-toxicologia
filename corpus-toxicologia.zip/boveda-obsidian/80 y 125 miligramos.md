---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "dosis habitual de MDA y MDMA · 80 y 125 miligramos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/dosis_habitual_de_MDA_y_MDMA__80_y_125_miligramos
---

# 80 y 125 miligramos

#graphify/concept #graphify/EXTRACTED #community/dosis_habitual_de_MDA_y_MDMA__80_y_125_miligramos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### dosis habitual de MDA y MDMA → 80 y 125 miligramos
Relación: oscila entre · concepto conectado: [[dosis habitual de MDA y MDMA|dosis habitual de MDA y MDMA]]

> La dosis habitual de MDA y MDMA oscila entre 80 y 125 miligramos.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `a16d7facd34189e42dbfdaf6b471a247f3ad3bd5502b14c7d9e2fb83927f4155`
Localizador: {"kind": "normalized_char_offsets", "start": 184277, "end": 186281}
