---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "consumo de LSD · OH-LSD"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/consumo_de_LSD__OH-LSD
---

# 3 fases: inicio o subida, viaje y vuelta o bajada

#graphify/concept #graphify/EXTRACTED #community/consumo_de_LSD__OH-LSD
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### consumo de LSD → 3 fases: inicio o subida, viaje y vuelta o bajada
Relación: produce · concepto conectado: [[consumo de LSD|consumo de LSD]]

> Durante el consumo de LSD se producen 3 fases: inicio o subida, viaje y vuelta o bajada.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f79b0abda30070462dc0dbad1952345958d92168299bc3859deb6f44d5d58454`
Localizador: {"kind": "normalized_char_offsets", "start": 269779, "end": 271932}
