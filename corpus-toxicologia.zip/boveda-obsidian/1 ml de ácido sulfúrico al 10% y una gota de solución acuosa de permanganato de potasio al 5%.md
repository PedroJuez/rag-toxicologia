---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1 ml de ácido sulfúrico al 10% y una gota de solución acuosa de permanganato de potasio al 5% · blanco de reactivos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_ml_de_cido_sulfrico_al_10_y_una_gota_de_solucin_acuosa_de_permanganato_de_potasio_al_5__blanco_de_reactivos
---

# 1 ml de ácido sulfúrico al 10% y una gota de solución acuosa de permanganato de potasio al 5%

#graphify/concept #graphify/EXTRACTED #community/1_ml_de_cido_sulfrico_al_10_y_una_gota_de_solucin_acuosa_de_permanganato_de_potasio_al_5__blanco_de_reactivos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### blanco de reactivos → 1 ml de ácido sulfúrico al 10% y una gota de solución acuosa de permanganato de potasio al 5%
Relación: se prepara utilizando · concepto conectado: [[blanco de reactivos|blanco de reactivos]]

> Preparar un blanco de reactivos utilizando 1 ml de ácido sulfúrico al 10% y una gota de solución acuosa de permanganato de potasio al 5%

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `07ba3f29789f28fae88beca8ee6092d122654a5410f1d343ee41cbc1768ce28e`
Localizador: {"kind": "normalized_char_offsets", "start": 277772, "end": 279901}
