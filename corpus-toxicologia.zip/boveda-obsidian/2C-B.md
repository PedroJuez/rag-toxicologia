---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "alcohol · 2C-B"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/alcohol__2C-B
---

# 2C-B

## Connections
- [[Cannabis]] - `se consume habitualmente con` [EXTRACTED]
- [[KETAMINA]] - `tiene descrito el consumo concomitante con` [EXTRACTED]
- [[alcohol]] - `se consume habitualmente con` [EXTRACTED]
- [[hongos psicodélicos]] - `tiene descrito el consumo concomitante con` [EXTRACTED]
- [[otras fenetilaminas como el MDMA]] - `se consume habitualmente con` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/alcohol__2C-B
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 2C-B → alcohol
Relación: se consume habitualmente con · concepto conectado: [[alcohol|alcohol]]

> El 2C-B se consume habitualmente con alcohol

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}

### 2C-B → Cannabis
Relación: se consume habitualmente con · concepto conectado: [[Cannabis|Cannabis]]

> El 2C-B se consume habitualmente con alcohol, cannabis

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}

### 2C-B → otras fenetilaminas como el MDMA
Relación: se consume habitualmente con · concepto conectado: [[otras fenetilaminas como el MDMA|otras fenetilaminas como el MDMA]]

> El 2C-B se consume habitualmente con alcohol, cannabis u otras fenetilaminas como el MDMA

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}

### 2C-B → KETAMINA
Relación: tiene descrito el consumo concomitante con · concepto conectado: [[KETAMINA|KETAMINA]]

> También se ha descrito el consumo concomitante de 2C-B con ketamina

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}

### 2C-B → hongos psicodélicos
Relación: tiene descrito el consumo concomitante con · concepto conectado: [[hongos psicodélicos|hongos psicodélicos]]

> consumo concomitante de 2C-B con ketamina u hongos psicodélicos

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}
