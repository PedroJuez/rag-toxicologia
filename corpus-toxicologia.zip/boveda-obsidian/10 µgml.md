---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "10 µg/ml · concentraciones en la orina de droga inalterada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/10_g/ml__concentraciones_en_la_orina_de_droga_inalterada
---

# 10 µg/ml

#graphify/concept #graphify/EXTRACTED #community/10_g/ml__concentraciones_en_la_orina_de_droga_inalterada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### concentraciones en la orina de droga inalterada → 10 µg/ml
Relación: son inferiores a (tras una sola dosis de MDA) · concepto conectado: [[concentraciones en la orina de droga inalterada|concentraciones en la orina de droga inalterada]]

> tras una sola dosis de MDA, las concentraciones en el plasma y la orina de droga inalterada son inferiores a 0,4 µg/ml y a 10 µg/ml, respectivamente.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `b01c48c25795d720afbe34884fcae0ed76521e05b2c84e516ba9b197d01542c6`
Localizador: {"kind": "normalized_char_offsets", "start": 204471, "end": 206680}
