---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA) · 50 a 90% de la dosis ingerida de bisulfuro de carbono"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/sulfato_inorgnico_tiourea_2-mercapto-2_-ona_y_2-tiotiazolidina-4-cido_carboxlico_TTCA__50_a_90_de_la_dosis_ingerida_de_bisulfuro_de_carbono
---

# 50 a 90% de la dosis ingerida de bisulfuro de carbono

## Connections
- [[sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA)]] - `se metaboliza y es excretado en la orina como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/sulfato_inorgnico_tiourea_2-mercapto-2_-ona_y_2-tiotiazolidina-4-cido_carboxlico_TTCA__50_a_90_de_la_dosis_ingerida_de_bisulfuro_de_carbono
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 50 a 90% de la dosis ingerida de bisulfuro de carbono → sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA)
Relación: se metaboliza y es excretado en la orina como · concepto conectado: [[sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA)|sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA)]]

> Un 50 a 90% de la dosis ingerida de bisulfuro de carbono se metaboliza y es excretado en la orina como sulfato inorgánico, tiourea, 2-mercapto-2 -ona y 2-tiotiazolidina-4-ácido carboxílico (TTCA).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3332a1f73ea2eca71de649c271d78ec7264c53c1b18938279ec871dc7c3e521e`
Localizador: {"kind": "normalized_char_offsets", "start": 151252, "end": 153392}
