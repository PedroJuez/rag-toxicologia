---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Agua · Ácido Perclórico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Agua__cido_Perclrico
---

# 62,4 g de fosfato diácido de sodio

## Connections
- [[Agua]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Agua__cido_Perclrico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 62,4 g de fosfato diácido de sodio → Agua
Relación: se disuelve en · concepto conectado: [[Agua|Agua]]

> Disolver 62,4 g de fosfato diácido de sodio en suficiente agua para producir 100 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6af27aa0bfb702e590bbd9b2403abe2de69fcc48aa14cb1947729335c1321a41`
Localizador: {"kind": "normalized_char_offsets", "start": 364173, "end": 366495}
