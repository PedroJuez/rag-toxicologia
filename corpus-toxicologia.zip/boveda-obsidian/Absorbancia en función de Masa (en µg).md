---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Absorbancia en función de Masa (en µg) · curva de calibración"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Absorbancia_en_funcin_de_Masa_en_g__curva_de_calibracin
---

# Absorbancia en función de Masa (en µg)

#graphify/concept #graphify/EXTRACTED #community/Absorbancia_en_funcin_de_Masa_en_g__curva_de_calibracin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### curva de calibración → Absorbancia en función de Masa (en µg)
Relación: está graficada como · concepto conectado: [[curva de calibración|curva de calibración]]

> curva de calibración, la cual está graficada como Absorbancia en función de Masa (en µg)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `8870079cdf625594a456f043198048917b9e4267d7666aaac5b76565b695b34b`
Localizador: {"kind": "normalized_char_offsets", "start": 281924, "end": 283501}
