---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "ATENOLOL · imipramina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/ATENOLOL__imipramina
---

# 2-[-4-(2-hidroxi-3-isopropilaminopropoxi)fenil]acetamida

#graphify/concept #graphify/EXTRACTED #community/ATENOLOL__imipramina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### ATENOLOL → 2-[-4-(2-hidroxi-3-isopropilaminopropoxi)fenil]acetamida
Relación: tiene sinónimo · concepto conectado: [[ATENOLOL|ATENOLOL]]

> Sinónimos: 2-[-4-(2-hidroxi-3-isopropilaminopropoxi)fenil]acetamida

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `fb628c88baae8fbf13c9a0619bb3ced348fb040a1371bf56b5bce6598e6f0137`
Localizador: {"kind": "normalized_char_offsets", "start": 122594, "end": 124792}
