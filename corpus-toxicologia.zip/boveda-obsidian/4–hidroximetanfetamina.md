---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "Metanfetamina · BZP"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Metanfetamina__BZP
---

# 4–hidroximetanfetamina

#graphify/concept #graphify/EXTRACTED #community/Metanfetamina__BZP
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Metanfetamina → 4–hidroximetanfetamina
Relación: tiene como principal metabolito a · concepto conectado: [[Metanfetamina|Metanfetamina]]

> La metanfetamina se excreta en forma de droga inalterada (44%) y de sus principales metabolitos, anfetamina (6% a 20%) y 4–hidroximetanfetamina (10%) [123].

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `acc6443341266c5defe1eab21da9e6471501d26e8a87e3284faed7430857fd31`
Localizador: {"kind": "normalized_char_offsets", "start": 160182, "end": 162308}
