---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "7 mm de diámetro · mechón de cabello"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/7_mm_de_dimetro__mechn_de_cabello
---

# 7 mm de diámetro

#graphify/concept #graphify/EXTRACTED #community/7_mm_de_dimetro__mechn_de_cabello
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### mechón de cabello → 7 mm de diámetro
Relación: debe tener un espesor mínimo de · concepto conectado: [[mechón de cabello|mechón de cabello]]

> Se debe recoger un mechón de cabello preferentemente occipital, muy cercano al cuero cabelludo, de un espesor mínimo de 7 mm de diámetro

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `809954c59607610dfecc08f7a7b27e0729059cb6353aaae5237370e53d94c12c`
Localizador: {"kind": "normalized_char_offsets", "start": 29298, "end": 31406}
