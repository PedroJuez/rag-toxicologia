---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "compartimiento externo · 0,5 ml de SO₄H26N"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/compartimiento_externo__05_ml_de_SOH26N
---

# 0,5 ml de SO₄H26N

## Connections
- [[compartimiento externo]] - `se agrega al` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/compartimiento_externo__05_ml_de_SOH26N
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 0,5 ml de SO₄H26N → compartimiento externo
Relación: se agrega al · concepto conectado: [[compartimiento externo|compartimiento externo]]

> agregar 0,5 ml de SO₄H26N al compartimiento externo

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f5ec2488a5dbd4697179229045625ed7c3900da1b4c340c5775b6f96520c17a8`
Localizador: {"kind": "normalized_char_offsets", "start": 190330, "end": 192499}
