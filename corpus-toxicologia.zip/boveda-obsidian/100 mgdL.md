---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "1 g/L de etanol · 21.70 mmol/L"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_g/L_de_etanol__2170_mmol/L
---

# 100 mg/dL

## Connections
- [[21.70 mmolL]] - `es equivalente a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/1_g/L_de_etanol__2170_mmol/L
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 g/L de etanol → 100 mg/dL
Relación: es equivalente a · concepto conectado: [[1 gL de etanol|1 g/L de etanol]]

> 1 g/L de etanol = 100 mg/dL

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `dd8c1a0e3ef9e6225a22fd5226f79c21af8105cb167e2c32d247fcad49c5bd7f`
Localizador: {"kind": "normalized_char_offsets", "start": 54679, "end": 56612}

### 100 mg/dL → 21.70 mmol/L
Relación: es equivalente a · concepto conectado: [[21.70 mmolL|21.70 mmol/L]]

> 100 mg/dL = 21.70 mmol/L

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `dd8c1a0e3ef9e6225a22fd5226f79c21af8105cb167e2c32d247fcad49c5bd7f`
Localizador: {"kind": "normalized_char_offsets", "start": 54679, "end": 56612}
