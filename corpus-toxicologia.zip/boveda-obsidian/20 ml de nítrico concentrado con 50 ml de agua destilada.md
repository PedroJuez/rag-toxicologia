---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "ácido clorhídrico · ácido clorhídrico concentrado"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/cido_clorhdrico__cido_clorhdrico_concentrado
---

# 20 ml de nítrico concentrado con 50 ml de agua destilada

#graphify/concept #graphify/EXTRACTED #community/cido_clorhdrico__cido_clorhdrico_concentrado
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### NO₃H 10 N → 20 ml de nítrico concentrado con 50 ml de agua destilada
Relación: se prepara mezclando · concepto conectado: [[NO₃H 10 N|NO₃H 10 N]]

> se prepara mezclando 20 ml de nítrico concentrado con 50 ml de agua destilada

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `7df874f03e2322e34e2ab732d15971df15ce1c9244ad2d9f47ced718d0044843`
Localizador: {"kind": "normalized_char_offsets", "start": 357219, "end": 359460}
