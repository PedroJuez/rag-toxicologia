---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "30 minutos aproximadamente · tiempo de extracción"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/30_minutos_aproximadamente__tiempo_de_extraccin
---

# 30 minutos aproximadamente

#graphify/concept #graphify/EXTRACTED #community/30_minutos_aproximadamente__tiempo_de_extraccin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### tiempo de extracción → 30 minutos aproximadamente
Relación: es de · concepto conectado: [[tiempo de extracción|tiempo de extracción]]

> el tiempo de extracción es de 30 minutos aproximadamente.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `21e91d89ed2b3850430fde4af2d6f910b1e3ab0d3e45a79b72b498e080c3683c`
Localizador: {"kind": "normalized_char_offsets", "start": 64394, "end": 66563}
