---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "2,74 minutos · El tiempo de retención de la anfetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/274_minutos__El_tiempo_de_retencin_de_la_anfetamina
---

# 2,74 minutos

#graphify/concept #graphify/EXTRACTED #community/274_minutos__El_tiempo_de_retencin_de_la_anfetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### El tiempo de retención de la anfetamina → 2,74 minutos
Relación: es con este régimen de · concepto conectado: [[El tiempo de retención de la anfetamina|El tiempo de retención de la anfetamina]]

> El tiempo de retención de la anfetamina es con este régimen de 2,74 minutos.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `bd35cb6082b507f9ab88fc7a9fdc3f847df6d4d190006ef98bf7d7c879642e97`
Localizador: {"kind": "normalized_char_offsets", "start": 199933, "end": 202272}
