---
source_file: "aa9042824a76474e04b695f550d4a1a7f6a031bab9025e002d4bda99fe4c46ee.md"
type: "concept"
community: "un tubo con EDTA como anticoagulante · 5 ml de sangre"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/un_tubo_con_EDTA_como_anticoagulante__5_ml_de_sangre
---

# 5 ml de sangre

## Connections
- [[un tubo con EDTA como anticoagulante]] - `se recogerán en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/un_tubo_con_EDTA_como_anticoagulante__5_ml_de_sangre
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 5 ml de sangre → un tubo con EDTA como anticoagulante
Relación: se recogerán en · concepto conectado: [[un tubo con EDTA como anticoagulante|un tubo con EDTA como anticoagulante]]

> Se recogerán 5 ml de sangre en un tubo con EDTA como anticoagulante.

Fuente: Orden Ministerial 13 de Mayo Recogida de muestras.pdf
Fragmento: `f0cb01be7427dad0d0c67b8afd0867d147a0d3e5a049511c508d831b06fb6705`
Localizador: {"kind": "normalized_char_offsets", "start": 37824, "end": 40224}
