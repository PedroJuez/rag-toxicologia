---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "fosfato monoácido disódico anhidro (0,025 M) · 110°C-130°C por 2 horas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/fosfato_monocido_disdico_anhidro_0025_M__110C-130C_por_2_horas
---

# 110°C-130°C por 2 horas

#graphify/concept #graphify/EXTRACTED #community/fosfato_monocido_disdico_anhidro_0025_M__110C-130C_por_2_horas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### fosfato monoácido disódico anhidro (0,025 M) → 110°C-130°C por 2 horas
Relación: secado a · concepto conectado: [[fosfato monoácido disódico anhidro (0,025 M)|fosfato monoácido disódico anhidro (0,025 M)]]

> fosfato monoácido disódico anhidro (0,025 M), ambos previamente secados a 110°C-130°C por 2 horas

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6af27aa0bfb702e590bbd9b2403abe2de69fcc48aa14cb1947729335c1321a41`
Localizador: {"kind": "normalized_char_offsets", "start": 364173, "end": 366495}
