---
source_file: "aa9042824a76474e04b695f550d4a1a7f6a031bab9025e002d4bda99fe4c46ee.md"
type: "concept"
community: "1 ml de sangre · tubo con EDTA o heparina como anticoagulante, refrigerado"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_ml_de_sangre__tubo_con_EDTA_o_heparina_como_anticoagulante_refrigerado
---

# 1 ml de sangre

## Connections
- [[tubo con EDTA o heparina como anticoagulante, refrigerado]] - `deberá enviarse en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/1_ml_de_sangre__tubo_con_EDTA_o_heparina_como_anticoagulante_refrigerado
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 ml de sangre → tubo con EDTA o heparina como anticoagulante, refrigerado
Relación: deberá enviarse en · concepto conectado: [[tubo con EDTA o heparina como anticoagulante, refrigerado|tubo con EDTA o heparina como anticoagulante, refrigerado]]

> Deberá enviarse 1 ml de sangre en un tubo con EDTA o heparina 
> como anticoagulante, refrigerado.

Fuente: Orden Ministerial 13 de Mayo Recogida de muestras.pdf
Fragmento: `1252f2164849244c21c77d9d14165cb5fbe8ffbe2340af3e6f8b9f08f245c8cf`
Localizador: {"kind": "normalized_char_offsets", "start": 53225, "end": 55625}

### un extremo del compartimento externo → 1 ml de sangre
Relación: recibe la colocación de · concepto conectado: [[un extremo del compartimento externo|un extremo del compartimento externo]]

> En un extremo del compartimento externo colocar 1 ml de sangre.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `bb205503edba348dbc64e46737cd7ea99745a1e828453534c552bc232dddf6b2`
Localizador: {"kind": "normalized_char_offsets", "start": 291614, "end": 294014}
