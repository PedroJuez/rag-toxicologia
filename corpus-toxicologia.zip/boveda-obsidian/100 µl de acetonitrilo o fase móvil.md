---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "Los extractos · un chorro de nitrógeno"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Los_extractos__un_chorro_de_nitrgeno
---

# 100 µl de acetonitrilo o fase móvil

#graphify/concept #graphify/EXTRACTED #community/Los_extractos__un_chorro_de_nitrgeno
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Los extractos → 100 µl de acetonitrilo o fase móvil
Relación: se vuelven a disolver en · concepto conectado: [[Los extractos|Los extractos]]

> después se vuelven a disolver en 100 µl de acetonitrilo o fase móvil

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `bd35cb6082b507f9ab88fc7a9fdc3f847df6d4d190006ef98bf7d7c879642e97`
Localizador: {"kind": "normalized_char_offsets", "start": 199933, "end": 202272}
