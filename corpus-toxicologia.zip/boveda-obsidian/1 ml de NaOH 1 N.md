---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "compartimiento interno · reactivo fijador"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/compartimiento_interno__reactivo_fijador
---

# 1 ml de NaOH 1 N

#graphify/concept #graphify/EXTRACTED #community/compartimiento_interno__reactivo_fijador
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### compartimiento interno → 1 ml de NaOH 1 N
Relación: recibe · concepto conectado: [[compartimiento interno|compartimiento interno]]

> colocar en el compartimiento interno 1 ml de NaOH 1 N

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
