---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "8 g de NaOH · NaOH 2N"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/8_g_de_NaOH__NaOH_2N
---

# 8 g de NaOH

#graphify/concept #graphify/EXTRACTED #community/8_g_de_NaOH__NaOH_2N
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### NaOH 2N → 8 g de NaOH
Relación: se prepara con · concepto conectado: [[NaOH 2N|NaOH 2N]]

> NaOH 2N: disolver 8 g de NaOH llevando a 100 ml con agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
