---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "abortivos · derivados de la ergotamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abortivos__derivados_de_la_ergotamina
---

# abortivos

#graphify/concept #graphify/EXTRACTED #community/abortivos__derivados_de_la_ergotamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### sales férricas (hierro III) → abortivos
Relación: han sido usadas como · concepto conectado: [[sales férricas (hierro III)|sales férricas (hierro III)]]

> Las sales férricas (hierro III) son más tóxicas y han sido usadas como abortivos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `668b1c4b47cc07b0299242ac704a775a94f18379946baf4aa24cb7e7f122b39d`
Localizador: {"kind": "normalized_char_offsets", "start": 246484, "end": 248441}

### derivados de la ergotamina → abortivos
Relación: se han utilizado como · concepto conectado: [[derivados de la ergotamina|derivados de la ergotamina]]

> 171 Los derivados de la ergotamina se han utilizado como abortivos (inductores de las contracciones uterinas); en la actualidad se utilizan con fines terapéuticos en el tratamiento de hemorragias postparto, de migrañas (dihidroergotamina), de la hipertensión arterial (dihidroergotocina) y en el tratamiento del Parkinson y la hiperprolactinemia (bromocriptina). También se han utilizado en investigación experimental.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `30a414f9a12563168770c7b57889685c0fcc6b7fa5051a17f60844b4f30c0d0d`
Localizador: {"kind": "normalized_char_offsets", "start": 265372, "end": 267646}
