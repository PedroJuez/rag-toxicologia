---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "10 mg/l · concentraciones de isoniazida en plasma durante la terapia"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/10_mg/l__concentraciones_de_isoniazida_en_plasma_durante_la_terapia
---

# 10 mg/l

#graphify/concept #graphify/EXTRACTED #community/10_mg/l__concentraciones_de_isoniazida_en_plasma_durante_la_terapia
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### concentraciones de bromuro en sueros normales → 10 mg/l
Relación: están por debajo de · concepto conectado: [[concentraciones de bromuro en sueros normales|concentraciones de bromuro en sueros normales]]

> Las concentraciones de bromuro en sueros normales están por debajo de 10 mg/l.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6eb5237e57599342d00d69de3878a21fd24deec0ef592f0928d32c6569ae8272`
Localizador: {"kind": "normalized_char_offsets", "start": 167946, "end": 170290}

### concentraciones de isoniazida en plasma durante la terapia → 10 mg/l
Relación: son menores de · concepto conectado: [[concentraciones de isoniazida en plasma durante la terapia|concentraciones de isoniazida en plasma durante la terapia]]

> Las concentraciones de isoniazida en plasma durante la terapia son menores de 10 mg/l.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `9d1cb91147fc8225b093bf3c52964ef007ebe53846d04facbc20a343b3d7ab36`
Localizador: {"kind": "normalized_char_offsets", "start": 258996, "end": 261353}
