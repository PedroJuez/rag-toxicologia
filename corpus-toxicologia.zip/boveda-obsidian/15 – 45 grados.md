---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Bebidas destiladas · 15 – 45 grados"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Bebidas_destiladas__15__45_grados
---

# 15 – 45 grados

#graphify/concept #graphify/EXTRACTED #community/Bebidas_destiladas__15__45_grados
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Bebidas destiladas → 15 – 45 grados
Relación: tienen una graduación de · concepto conectado: [[Bebidas destiladas|Bebidas destiladas]]

> Bebidas destiladas 15 – 45 grados

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `924b35dd7b5ac3a92774e3e73c44325cae1443d524e8fec9c3c82c948faca85d`
Localizador: {"kind": "normalized_char_offsets", "start": 42359, "end": 44652}
