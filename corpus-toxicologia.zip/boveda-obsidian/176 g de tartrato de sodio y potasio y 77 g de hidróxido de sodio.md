---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "176 g de tartrato de sodio y potasio y 77 g de hidróxido de sodio · suficiente agua para producir 500 ml"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/176_g_de_tartrato_de_sodio_y_potasio_y_77_g_de_hidrxido_de_sodio__suficiente_agua_para_producir_500_ml
---

# 176 g de tartrato de sodio y potasio y 77 g de hidróxido de sodio

## Connections
- [[suficiente agua para producir 500 ml]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/176_g_de_tartrato_de_sodio_y_potasio_y_77_g_de_hidrxido_de_sodio__suficiente_agua_para_producir_500_ml
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 176 g de tartrato de sodio y potasio y 77 g de hidróxido de sodio → suficiente agua para producir 500 ml
Relación: se disuelve en · concepto conectado: [[suficiente agua para producir 500 ml|suficiente agua para producir 500 ml]]

> Disolver 176 g de tartrato de sodio y potasio y 77 g de hidróxido de sodio en suficiente agua para producir 500 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
