---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "DMMDA · 2,5-dimetoxi-3,4-metilenedioxianfetanina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/DMMDA__25-dimetoxi-34-metilenedioxianfetanina
---

# 2,5-dimetoxi-3,4-metilenedioxianfetanina

#graphify/concept #graphify/EXTRACTED #community/DMMDA__25-dimetoxi-34-metilenedioxianfetanina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### DMMDA → 2,5-dimetoxi-3,4-metilenedioxianfetanina
Relación: es · concepto conectado: [[DMMDA|DMMDA]]

> - Otros como: DMMDA (2,5-dimetoxi-3,4-metilenedioxianfetanina)...

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `ec0e1fcf19c7d252e59c5c579d4b8b3ab5355d99b3131babf6090f070258e192`
Localizador: {"kind": "normalized_char_offsets", "start": 185021, "end": 187176}
