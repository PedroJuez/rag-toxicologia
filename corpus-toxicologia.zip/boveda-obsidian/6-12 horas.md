---
source_file: "bffa95dfb281355e9b484b266034f2d461d14324f48862c16e051513ac9af478.md"
type: "concept"
community: "ALPRAZOLAM · hasta 5-7 días"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/ALPRAZOLAM__hasta_5-7_das
---

# 6-12 horas

#graphify/concept #graphify/EXTRACTED #community/ALPRAZOLAM__hasta_5-7_das
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### ALPRAZOLAM → 6-12 horas
Relación: tiene vida media de · concepto conectado: [[ALPRAZOLAM|ALPRAZOLAM]]

> Vida media: 6-12 horas

Fuente: BASE DE CONOCIMIENTO TOXICOLÓGICA.pdf
Fragmento: `5e83dc2198b77323da8d8d50d550eb733329b2818c10c548f7514c6d6da04153`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 1122, "pdf_page": 1}
