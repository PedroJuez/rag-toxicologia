---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "THC · CEDIA"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/THC__CEDIA
---

# 11-Nor-*delta*-9-THC-9- Carbonsäure

## Connections
- [[THC]] - `es metabolito de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/THC__CEDIA
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 11-Nor-*delta*-9-THC-9- Carbonsäure → THC
Relación: es metabolito de · concepto conectado: [[THC|THC]]

> Routine-Nachweis des THC-Metaboliten 11-Nor-*delta*-9-THC-9- Carbonsäure in der forensischen Praxis

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `0cd1f48b5b1f25760df712d56472063653edf08f61127750b1ea3295ce43ca9b`
Localizador: {"kind": "normalized_char_offsets", "start": 216060, "end": 218332}
