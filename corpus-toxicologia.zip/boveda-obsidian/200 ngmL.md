---
source_file: "bffa95dfb281355e9b484b266034f2d461d14324f48862c16e051513ac9af478.md"
type: "concept"
community: "ALPRAZOLAM · Benzodiacepinas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/ALPRAZOLAM__Benzodiacepinas
---

# >200 ng/mL

#graphify/concept #graphify/EXTRACTED #community/ALPRAZOLAM__Benzodiacepinas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### ALPRAZOLAM → >200 ng/mL
Relación: tiene concentración potencialmente letal de · concepto conectado: [[ALPRAZOLAM|ALPRAZOLAM]]

> Concentración potencialmente letal: >200 ng/mL

Fuente: BASE DE CONOCIMIENTO TOXICOLÓGICA.pdf
Fragmento: `5e83dc2198b77323da8d8d50d550eb733329b2818c10c548f7514c6d6da04153`
Localizador: {"kind": "normalized_char_offsets", "start": 0, "end": 1122, "pdf_page": 1}
