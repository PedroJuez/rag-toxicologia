---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "absorbancia · 520 nm"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorbancia__520_nm
---

# absorbancia del extracto

## Connections
- [[520 nm]] - `se mide a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorbancia__520_nm
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbancia del extracto → 520 nm
Relación: se mide a · concepto conectado: [[520 nm|520 nm]]

> medir la absorbancia del extracto a 520 nm contra blanco de reactivo

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `406a0244d6d87b4f4833ed42997e59aff7934844f6f68a324db71b553695a395`
Localizador: {"kind": "normalized_char_offsets", "start": 250434, "end": 252730}
