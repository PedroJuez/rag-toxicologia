---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "solución de hidróxido de amonio- ditionito · absorbancia de las soluciones x, y, z"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/solucin_de_hidrxido_de_amonio-_ditionito__absorbancia_de_las_soluciones_x_y_z
---

# absorbancia de las soluciones x, y, z

## Connections
- [[solución de hidróxido de amonio- ditionito]] - `medir contra` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/solucin_de_hidrxido_de_amonio-_ditionito__absorbancia_de_las_soluciones_x_y_z
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbancia de las soluciones x, y, z → solución de hidróxido de amonio- ditionito
Relación: medir contra · concepto conectado: [[solución de hidróxido de amonio- ditionito|solución de hidróxido de amonio- ditionito]]

> Medir la absorbancia de las soluciones x, y, z contra la solución de hidróxido de amonio- ditionito a 540 nm y 579 nm.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `0fe4121ca47b30d8e7139bd3d596fd552d72605b91aa496e63665f816232766d`
Localizador: {"kind": "normalized_char_offsets", "start": 287975, "end": 289338}
