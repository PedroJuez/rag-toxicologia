---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "100 ug de NaCN por mililitro · Esta solución"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/100_ug_de_NaCN_por_mililitro__Esta_solucin
---

# 100 ug de NaCN por mililitro

#graphify/concept #graphify/EXTRACTED #community/100_ug_de_NaCN_por_mililitro__Esta_solucin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Esta solución → 100 ug de NaCN por mililitro
Relación: contiene · concepto conectado: [[Esta solución|Esta solución]]

> Esta solución contiene 100 ug de NaCN por mililitro

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f5ec2488a5dbd4697179229045625ed7c3900da1b4c340c5775b6f96520c17a8`
Localizador: {"kind": "normalized_char_offsets", "start": 190330, "end": 192499}
