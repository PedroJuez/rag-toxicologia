---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "34 a 38% p/p de formaldehído · Formaldehído o Formalina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/34_a_38_p/p_de_formaldehdo__Formaldehdo_o_Formalina
---

# 34 a 38% p/p de formaldehído

#graphify/concept #graphify/EXTRACTED #community/34_a_38_p/p_de_formaldehdo__Formaldehdo_o_Formalina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Formaldehído o Formalina → 34 a 38% p/p de formaldehído
Relación: contiene · concepto conectado: [[Formaldehído o Formalina|Formaldehído o Formalina]]

> Contiene 34 a 38% p/p de formaldehído.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `7df874f03e2322e34e2ab732d15971df15ce1c9244ad2d9f47ced718d0044843`
Localizador: {"kind": "normalized_char_offsets", "start": 357219, "end": 359460}
