---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "20 ml de b) · 80 ml de a)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/20_ml_de_b__80_ml_de_a
---

# 20 ml de b)

#graphify/concept #graphify/EXTRACTED #community/20_ml_de_b__80_ml_de_a
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 80 ml de a) → 20 ml de b)
Relación: se mezcla con · concepto conectado: [[80 ml de a)|80 ml de a)]]

> Mezclar 80 ml de a) con 20 ml de b) para obtener una solución de pH 7,4.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6af27aa0bfb702e590bbd9b2403abe2de69fcc48aa14cb1947729335c1321a41`
Localizador: {"kind": "normalized_char_offsets", "start": 364173, "end": 366495}
