---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "0,01 g de Rodamina B · 100 ml de agua destilada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/001_g_de_Rodamina_B__100_ml_de_agua_destilada
---

# 100 ml de agua destilada

#graphify/concept #graphify/EXTRACTED #community/001_g_de_Rodamina_B__100_ml_de_agua_destilada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 0,01 g de Rodamina B → 100 ml de agua destilada
Relación: se disuelve en · concepto conectado: [[0,01 g de Rodamina B|0,01 g de Rodamina B]]

> Disolver 0,01 g de Rodamina B en 100 ml de agua destilada

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `5ed22968d7d98b017330ef3508f2544159bc283c7e423ac709868b409e5a45fd`
Localizador: {"kind": "normalized_char_offsets", "start": 111285, "end": 113446}
