---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "monóxido de carbono · Ditionito de sodio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/monxido_de_carbono__Ditionito_de_sodio
---

# 3 ml

#graphify/concept #graphify/EXTRACTED #community/monxido_de_carbono__Ditionito_de_sodio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### monóxido de carbono → 3 ml
Relación: requiere volumen mínimo de · concepto conectado: [[monóxido de carbono|monóxido de carbono]]

> **Monóxido de carbono** al laboratorio- Co-oxímetro aguja y con tapón plástico Volumen mínimo: 3 ml

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `0b3e3d8121b25fc31ed9f4dec089ac803ecd029d66183b58eb86a8a84dbc9d44`
Localizador: {"kind": "normalized_char_offsets", "start": 371249, "end": 373648}
