---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1,2-naftoquinona-4-sulfonato de sodio · mezcla de etanol:agua (1:1)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/12-naftoquinona-4-sulfonato_de_sodio__mezcla_de_etanolagua_11
---

# 1,2-naftoquinona-4-sulfonato de sodio

## Connections
- [[mezcla de etanolagua (11)]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/12-naftoquinona-4-sulfonato_de_sodio__mezcla_de_etanolagua_11
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1,2-naftoquinona-4-sulfonato de sodio → mezcla de etanol:agua (1:1)
Relación: se disuelve en · concepto conectado: [[mezcla de etanolagua (11)|mezcla de etanol:agua (1:1)]]

> Disolver 0,3 g de 1,2-naftoquinona-4-sulfonato de sodio en 100 ml de una mezcla de etanol:agua (1:1).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `e297554f77f05514d06fd8bf9f34c3652444a7ebd015e6cf3effd82042808ea0`
Localizador: {"kind": "normalized_char_offsets", "start": 359460, "end": 361850}
