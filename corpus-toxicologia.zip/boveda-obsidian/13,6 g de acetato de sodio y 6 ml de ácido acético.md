---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "cantidad suficiente para producir 1000 ml · 13,6 g de acetato de sodio y 6 ml de ácido acético"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/cantidad_suficiente_para_producir_1000_ml__136_g_de_acetato_de_sodio_y_6_ml_de_cido_actico
---

# 13,6 g de acetato de sodio y 6 ml de ácido acético

## Connections
- [[cantidad suficiente para producir 1000 ml]] - `se disuelven en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/cantidad_suficiente_para_producir_1000_ml__136_g_de_acetato_de_sodio_y_6_ml_de_cido_actico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 13,6 g de acetato de sodio y 6 ml de ácido acético → cantidad suficiente para producir 1000 ml
Relación: se disuelven en · concepto conectado: [[cantidad suficiente para producir 1000 ml|cantidad suficiente para producir 1000 ml]]

> Disolver 13,6 g de acetato de sodio y 6 ml de ácido acético en cantidad suficiente para producir 1000 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
