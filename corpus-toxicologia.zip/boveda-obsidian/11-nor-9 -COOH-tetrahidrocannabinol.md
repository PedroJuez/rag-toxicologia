---
source_file: "6063972895f0ee635dfe940329b5666d9be5c3e5c39e7652596dac33e16e4eb9.md"
type: "concept"
community: "11-nor-9 -COOH-tetrahidrocannabinol · THC del cannabis"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/11-nor-9_-COOH-tetrahidrocannabinol__THC_del_cannabis
---

# 11-nor-9 -COOH-tetrahidrocannabinol

## Connections
- [[THC del cannabis]] - `es metabolito del` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/11-nor-9_-COOH-tetrahidrocannabinol__THC_del_cannabis
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 11-nor-9 -COOH-tetrahidrocannabinol → THC del cannabis
Relación: es metabolito del · concepto conectado: [[THC del cannabis|THC del cannabis]]

> 11-nor-9 -COOH-tetrahidrocannabinol (metabolito del THC del cannabis)

Fuente: analisisdrogasabuso.pdf
Fragmento: `df3a90630d6f1f6fff15688cc7c99ce766228d3d2a36e71cfa1dc00b54305967`
Localizador: {"kind": "normalized_char_offsets", "start": 6207, "end": 8606}
