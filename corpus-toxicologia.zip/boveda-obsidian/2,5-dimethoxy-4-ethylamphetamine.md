---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "DOET · entre el 10% y el 40%"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/DOET__entre_el_10_y_el_40
---

# 2,5-dimethoxy-4-ethylamphetamine

## Connections
- [[DOET]] - `es sinónimo de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/DOET__entre_el_10_y_el_40
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 2,5-dimethoxy-4-ethylamphetamine → DOET
Relación: es sinónimo de · concepto conectado: [[DOET|DOET]]

> 2,5-dimethoxy-4-ethylamphetamine (DOET)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `5a1cdaddd707042eb08d451200409dec266acbb95499d9146b045edbc3bdcfca`
Localizador: {"kind": "normalized_char_offsets", "start": 232303, "end": 234542}
