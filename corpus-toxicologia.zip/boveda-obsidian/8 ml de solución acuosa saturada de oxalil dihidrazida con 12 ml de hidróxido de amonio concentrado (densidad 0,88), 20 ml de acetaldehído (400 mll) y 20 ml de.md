---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Reactivo de Oxalil dihidrazida · 8 ml de solución acuosa saturada de oxalil dihidrazida con 12 ml de hidróxido de amonio concentrado (densidad 0,88), 20 ml de acetaldehído (400 ml/l) y 20 ml de"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Reactivo_de_Oxalil_dihidrazida__8_ml_de_solucin_acuosa_saturada_de_oxalil_dihidrazida_con_12_ml_de_hidrxido_de_amonio_concentrado_densidad_088_20_ml_de_acetaldehdo_400_ml/l_y_20_ml_de
---

# 8 ml de solución acuosa saturada de oxalil dihidrazida con 12 ml de hidróxido de amonio concentrado (densidad 0,88), 20 ml de acetaldehído (400 ml/l) y 20 ml de

#graphify/concept #graphify/EXTRACTED #community/Reactivo_de_Oxalil_dihidrazida__8_ml_de_solucin_acuosa_saturada_de_oxalil_dihidrazida_con_12_ml_de_hidrxido_de_amonio_concentrado_densidad_088_20_ml_de_acetaldehdo_400_ml/l_y_20_ml_de
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Reactivo de Oxalil dihidrazida → 8 ml de solución acuosa saturada de oxalil dihidrazida con 12 ml de hidróxido de amonio concentrado (densidad 0,88), 20 ml de acetaldehído (400 ml/l) y 20 ml de
Relación: se prepara mediante la mezcla de · concepto conectado: [[Reactivo de Oxalil dihidrazida|Reactivo de Oxalil dihidrazida]]

> Reactivo de Oxalil dihidrazida: Mezclar 8 ml de solución acuosa saturada de oxalil dihidrazida con 12 ml de hidróxido de amonio concentrado (densidad 0,88), 20 ml de acetaldehído (400 ml/l) y 20 ml de agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `82bbc170626aee620c0d102070933d1fcb059696299ec91b38230d488d71ca39`
Localizador: {"kind": "normalized_char_offsets", "start": 200897, "end": 203137}
