---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "100 ml de agua · 6 g de nitrato de cobalto y 18 g de tiocianato de potasio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/100_ml_de_agua__6_g_de_nitrato_de_cobalto_y_18_g_de_tiocianato_de_potasio
---

# 6 g de nitrato de cobalto y 18 g de tiocianato de potasio

## Connections
- [[100 ml de agua]] - `se disuelven en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/100_ml_de_agua__6_g_de_nitrato_de_cobalto_y_18_g_de_tiocianato_de_potasio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 6 g de nitrato de cobalto y 18 g de tiocianato de potasio → 100 ml de agua
Relación: se disuelven en · concepto conectado: [[100 ml de agua|100 ml de agua]]

> Disolver 6 g de nitrato de cobalto y 18 g de tiocianato de potasio en 100 ml de agua.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
