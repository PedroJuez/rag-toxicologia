---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Este ensayo · Antimonio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Este_ensayo__Antimonio
---

# 4- aminosalicilato

## Connections
- [[Este ensayo]] - `interfiere si está presente a una alta concentración en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Este_ensayo__Antimonio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 4- aminosalicilato → Este ensayo
Relación: interfiere si está presente a una alta concentración en · concepto conectado: [[Este ensayo|Este ensayo]]

> El 4- aminosalicilato también interfiere, pero sólo si está presente a una alta concentración.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `a1000a7529e0bd14cb86ce83afd280120c82631289d67e9c77ea26066a0f555c`
Localizador: {"kind": "normalized_char_offsets", "start": 261353, "end": 263619}
