---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "CLAR · lidocaína"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/CLAR__lidocana
---

# 9-carboxi-THC

## Connections
- [[glucurónido conjugado]] - `está presente en la orina en forma de` [EXTRACTED]
- [[mancha de color rosa o rojo rosado]] - `aparece como` [EXTRACTED]
- [[material de diversos tipos de recipientes]] - `se absorbe irreversiblemente al` [EXTRACTED]
- [[principal metabolito]] - `es` [EXTRACTED]
- [[una semana o más]] - `es posible detectar durante` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/CLAR__lidocana
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Procedimientos de muestreo y preparación de la muestra → 9-carboxi-THC
Relación: para el análisis de · concepto conectado: [[Procedimientos de muestreo y preparación de la muestra|Procedimientos de muestreo y preparación de la muestra]]

> Procedimientos de muestreo y preparación de la muestra para el análisis de
> 9-carboxi-THC

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `f22fbd1978288e7013319acffe66c57bb360da7f44b3429e2585f82da76684f2`
Localizador: {"kind": "normalized_char_offsets", "start": 3631, "end": 5922}

### 9-carboxi-THC → principal metabolito
Relación: es · concepto conectado: [[principal metabolito|principal metabolito]]

> el principal metabolito, 9-carboxi-THC

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9ca9cffb2ea1cbadf8121b5c621461012c6489119563a57d1afd227902a85703`
Localizador: {"kind": "normalized_char_offsets", "start": 111905, "end": 114129}

### 9-carboxi-THC → material de diversos tipos de recipientes
Relación: se absorbe irreversiblemente al · concepto conectado: [[material de diversos tipos de recipientes|material de diversos tipos de recipientes]]

> el 9-carboxi-THC se absorbe irreversiblemente al material de diversos tipos de recipientes

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9ca9cffb2ea1cbadf8121b5c621461012c6489119563a57d1afd227902a85703`
Localizador: {"kind": "normalized_char_offsets", "start": 111905, "end": 114129}

### 9-carboxi-THC → glucurónido conjugado
Relación: está presente en la orina en forma de · concepto conectado: [[glucurónido conjugado|glucurónido conjugado]]

> Más del 80% del metabolito de cannabinoide excretado, 9-carboxi-THC, está presente en la orina en forma de glucurónido conjugado.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `9ca9cffb2ea1cbadf8121b5c621461012c6489119563a57d1afd227902a85703`
Localizador: {"kind": "normalized_char_offsets", "start": 111905, "end": 114129}

### mayoría de los inmunoanálisis → 9-carboxi-THC
Relación: detecta · concepto conectado: [[mayoría de los inmunoanálisis|mayoría de los inmunoanálisis]]

> Con la mayoría de los inmunoanálisis se detecta el 9-carboxi-THC

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `79e9f9d0f77c12947ae2ec49cf9d1c3431356cf3695e6393cce8c055991ee440`
Localizador: {"kind": "normalized_char_offsets", "start": 116384, "end": 118657}

### cromatografía en fase líquida de alto rendimiento → 9-carboxi-THC
Relación: permite la rápida detección de · concepto conectado: [[cromatografía en fase líquida de alto rendimiento|cromatografía en fase líquida de alto rendimiento]]

> Permite la rápida detección de 9-carboxi-THC a un nivel bajo de ng/ml sin derivación previa.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `6009669f2db415af7d597b20308fd64df8e22d3baa711ad4f69cea40cfc74061`
Localizador: {"kind": "normalized_char_offsets", "start": 124903, "end": 127170}

### 9-carboxi-THC → una semana o más
Relación: es posible detectar durante · concepto conectado: [[una semana o más|una semana o más]]

> es posible detectar el 9-carboxi-THC durante una semana o más

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `11b67ea238c27d3606dafed828c949289a3165557cc942c1a476b092d6f1d120`
Localizador: {"kind": "normalized_char_offsets", "start": 127170, "end": 128977}

### 9-carboxi-THC → mancha de color rosa o rojo rosado
Relación: aparece como · concepto conectado: [[mancha de color rosa o rojo rosado|mancha de color rosa o rojo rosado]]

> El 9-carboxi-THC aparece como una mancha de color rosa o rojo rosado al mismo valor Rfque la mancha patrón del 9- carboxi-THC.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `1331278b7ddc099a52ec8dc66a1921c688970ebe4fc754bb0397553d445b4d98`
Localizador: {"kind": "normalized_char_offsets", "start": 120696, "end": 122528}
