---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "metabolitos · pelo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/metabolitos__pelo
---

# 70% de una dosis

## Connections
- [[metabolitos]] - `se excreta en la orina como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/metabolitos__pelo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 70% de una dosis → metabolitos
Relación: se excreta en la orina como · concepto conectado: [[metabolitos|metabolitos]]

> Un 70% de una dosis se excreta en la orina como metabolitos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `9d1cb91147fc8225b093bf3c52964ef007ebe53846d04facbc20a343b3d7ab36`
Localizador: {"kind": "normalized_char_offsets", "start": 258996, "end": 261353}
