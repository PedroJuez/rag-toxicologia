---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "5 g de molibdato de amonio en 100 ml de agua destilada y 35 ml de ácido nítrico concentrado · Reactivo de molibdato de amonio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/5_g_de_molibdato_de_amonio_en_100_ml_de_agua_destilada_y_35_ml_de_cido_ntrico_concentrado__Reactivo_de_molibdato_de_amonio
---

# 5 g de molibdato de amonio en 100 ml de agua destilada y 35 ml de ácido nítrico concentrado

#graphify/concept #graphify/EXTRACTED #community/5_g_de_molibdato_de_amonio_en_100_ml_de_agua_destilada_y_35_ml_de_cido_ntrico_concentrado__Reactivo_de_molibdato_de_amonio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Reactivo de molibdato de amonio → 5 g de molibdato de amonio en 100 ml de agua destilada y 35 ml de ácido nítrico concentrado
Relación: se obtiene al mezclar · concepto conectado: [[Reactivo de molibdato de amonio|Reactivo de molibdato de amonio]]

> Reactivo de molibdato de amonio. Mezclar 5 g de molibdato de amonio en 100 ml de agua destilada y 35 ml de ácido nítrico concentrado (densidad 1,42).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b17422d6b1dbfbcb88b49586f4157e3c2875b7ef30eb1c469b2a00372efa7aa8`
Localizador: {"kind": "normalized_char_offsets", "start": 240714, "end": 242998}
