---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "KETAMINA · Metoxetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/KETAMINA__Metoxetamina
---

# 2-C-B-FLY

## Connections
- [[compuestos derivados del benzofifurano o compuestos FLY]] - `es un ejemplo de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/KETAMINA__Metoxetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 2-C-B-FLY → compuestos derivados del benzofifurano o compuestos FLY
Relación: es un ejemplo de · concepto conectado: [[compuestos derivados del benzofifurano o compuestos FLY|compuestos derivados del benzofifurano o compuestos FLY]]

> Compuestos derivados del benzofifurano o compuestos FLY: 2-C-B-FLY

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `092221ddcce3daa5e5b924a8d9898a1eccc8b28309e9f0ccd0bd94eaa1baaeda`
Localizador: {"kind": "normalized_char_offsets", "start": 234408, "end": 236461}
