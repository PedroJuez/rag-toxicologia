---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "MDVP · 3,4-metilenedioxipirovalerona"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/MDVP__34-metilenedioxipirovalerona
---

# 3,4-metilenedioxipirovalerona

## Connections
- [[MDVP]] - `es denominada con la sigla` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/MDVP__34-metilenedioxipirovalerona
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3,4-metilenedioxipirovalerona → MDVP
Relación: es denominada con la sigla · concepto conectado: [[MDVP|MDVP]]

> 3,4-metilenedioxipirovalerona (MDVP)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `7bebe2f6977ad4987e633c30d7afc88cc204faef8a1b3bd17e15032894362490`
Localizador: {"kind": "normalized_char_offsets", "start": 225789, "end": 227900}
