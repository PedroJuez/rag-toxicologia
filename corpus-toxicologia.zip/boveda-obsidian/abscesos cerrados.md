---
source_file: "aa9042824a76474e04b695f550d4a1a7f6a031bab9025e002d4bda99fe4c46ee.md"
type: "concept"
community: "jeringa y aguja · abscesos cerrados"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/jeringa_y_aguja__abscesos_cerrados
---

# abscesos cerrados

## Connections
- [[jeringa y aguja]] - `la toma se hace aspirando el pus con` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/jeringa_y_aguja__abscesos_cerrados
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### abscesos cerrados → jeringa y aguja
Relación: la toma se hace aspirando el pus con · concepto conectado: [[jeringa y aguja|jeringa y aguja]]

> Abscesos: en los cerrados la toma se hace aspirando el pus con jeringa y aguja

Fuente: Orden Ministerial 13 de Mayo Recogida de muestras.pdf
Fragmento: `7e50961cfebced7982ac16cbe33569e1c5c1577a306664ee913e480e10f42783`
Localizador: {"kind": "normalized_char_offsets", "start": 62825, "end": 64776}
