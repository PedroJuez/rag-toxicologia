---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "residuo · 0,1 ml de metanol o metanol-cloroformo (9:1)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
---

# 0,1 ml de metanol

#graphify/concept #graphify/EXTRACTED #community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### residuo → 0,1 ml de metanol
Relación: se vuelve a disolver en · concepto conectado: [[residuo|residuo]]

> se vuelve a disolver el residuo en 0,1 ml de metanol

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `203592cccc96c3cf217db325edf2817f8824f1444a30c7570827b0e9d294a4c1`
Localizador: {"kind": "normalized_char_offsets", "start": 114129, "end": 116384}
