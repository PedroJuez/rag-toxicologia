---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "dimetilsilicona · OV-1"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/dimetilsilicona__OV-1
---

# 3% dimetil silicona

## Connections
- [[OV-1]] - `se identifica como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/dimetilsilicona__OV-1
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3% dimetil silicona → OV-1
Relación: se identifica como · concepto conectado: [[OV-1|OV-1]]

> Detector: Detector de ionización de llama Columna: 2 m X 2 mm de D.I. Relleno: *a)* 3% dimetil silicona (OV-1)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `50b815806788b515c1c29df59522e48e10a93978198d6eae2c261746a4a50750`
Localizador: {"kind": "normalized_char_offsets", "start": 122528, "end": 124903}
