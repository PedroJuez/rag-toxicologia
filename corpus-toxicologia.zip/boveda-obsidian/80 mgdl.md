---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "80 mg/dl · Solución testigo de etanol"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/80_mg/dl__Solucin_testigo_de_etanol
---

# 80 mg/dl

#graphify/concept #graphify/EXTRACTED #community/80_mg/dl__Solucin_testigo_de_etanol
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Solución testigo de etanol → 80 mg/dl
Relación: tiene concentración de · concepto conectado: [[Solución testigo de etanol|Solución testigo de etanol]]

> Solución testigo de etanol: 80 mg/dl.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2299a4eb5dff036a494fa534d3fd813391291cfb6b45479a76ed16189febb47c`
Localizador: {"kind": "normalized_char_offsets", "start": 229828, "end": 232169}
