---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "suficiente agua para producir 100 ml · 2 g de yodo y 3 g ioduro de potasio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/suficiente_agua_para_producir_100_ml__2_g_de_yodo_y_3_g_ioduro_de_potasio
---

# 2 g de yodo y 3 g ioduro de potasio

## Connections
- [[suficiente agua para producir 100 ml]] - `se disuelven en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/suficiente_agua_para_producir_100_ml__2_g_de_yodo_y_3_g_ioduro_de_potasio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 2 g de yodo y 3 g ioduro de potasio → suficiente agua para producir 100 ml
Relación: se disuelven en · concepto conectado: [[suficiente agua para producir 100 ml|suficiente agua para producir 100 ml]]

> Disolver 2 g de yodo y 3 g ioduro de potasio en suficiente agua para producir 100 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
