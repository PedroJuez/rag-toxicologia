---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1,8 mg/l (34 µmol/l) · concentraciones férricas normales en suero"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/18_mg/l_34_mol/l__concentraciones_frricas_normales_en_suero
---

# 1,8 mg/l (34 µmol/l)

#graphify/concept #graphify/EXTRACTED #community/18_mg/l_34_mol/l__concentraciones_frricas_normales_en_suero
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### concentraciones férricas normales en suero → 1,8 mg/l (34 µmol/l)
Relación: están por debajo de · concepto conectado: [[concentraciones férricas normales en suero|concentraciones férricas normales en suero]]

> Las concentraciones férricas normales en suero están por debajo 1,8 mg/l (34 µmol/l).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `b30cf4fa58c43d0cebbd2a75a79887abc4ec8dd9cacf00d373d1f7e90c1d1e02`
Localizador: {"kind": "normalized_char_offsets", "start": 248441, "end": 250434}
