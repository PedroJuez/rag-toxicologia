---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "heroína · opio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/herona__opio
---

# 0,6 horas

#graphify/concept #graphify/EXTRACTED #community/herona__opio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### MAM → 0,6 horas
Relación: tiene un período de semidesintegración de · concepto conectado: [[MAM|MAM]]

> se metaboliza a morfina con relativa rapidez (período de semidesintegración: 0,6 horas [19])

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `3589e8ed20298b98a871d647d3d53feac22457038cf00c752877392514ce06c6`
Localizador: {"kind": "normalized_char_offsets", "start": 58337, "end": 60400}
