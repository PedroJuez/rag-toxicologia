---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "CLAR · lidocaína"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/CLAR__lidocana
---

# 5 µg/ml

#graphify/concept #graphify/EXTRACTED #community/CLAR__lidocana
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### patrón interno → 5 µg/ml
Relación: tiene una concentración de · concepto conectado: [[patrón interno|patrón interno]]

> el patrón interno con una concentración de 5 µg/ml

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `7590c07ebf8d144d876456b06da020142a00da0d8e65ae64f756395f1b69abf1`
Localizador: {"kind": "normalized_char_offsets", "start": 193098, "end": 195202}

### concentraciones correspondientes de droga en la orina → 5 µg/ml
Relación: son inferiores a (en cuanto a la PMA) · concepto conectado: [[concentraciones correspondientes de droga en la orina|concentraciones correspondientes de droga en la orina]]

> En cuanto a la PMA, las concentraciones correspondientes de droga en el plasma y la orina son inferiores a 0,2 µg/ml y 5 µg/ml, respectivamente

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `b01c48c25795d720afbe34884fcae0ed76521e05b2c84e516ba9b197d01542c6`
Localizador: {"kind": "normalized_char_offsets", "start": 204471, "end": 206680}
