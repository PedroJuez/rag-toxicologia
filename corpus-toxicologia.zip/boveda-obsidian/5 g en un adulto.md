---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "plaguicidas organoclorados · aldrin, dieldrin y endrin"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/plaguicidas_organoclorados__aldrin_dieldrin_y_endrin
---

# 5 g en un adulto

#graphify/concept #graphify/EXTRACTED #community/plaguicidas_organoclorados__aldrin_dieldrin_y_endrin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### aldrin, dieldrin y endrin → 5 g en un adulto
Relación: tienen dosis letal aguda aproximada de · concepto conectado: [[aldrin, dieldrin y endrin|aldrin, dieldrin y endrin]]

> Los plaguicidas organoclorados aldrin, dieldrin y endrin (dosis letal aguda aproximada, 5 g en un adulto) son más tóxicos que el lindano o DDT (la dosis letal aproximada, 30 g).

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `85258ffd2e50e77111e371b23bfcdbee4944af0e664a76c40103074af055dd72`
Localizador: {"kind": "normalized_char_offsets", "start": 324896, "end": 326881}
