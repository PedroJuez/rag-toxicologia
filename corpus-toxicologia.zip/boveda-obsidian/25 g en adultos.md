---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "dosis letal por vía oral de lidocaína · 25 g en adultos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/dosis_letal_por_va_oral_de_lidocana__25_g_en_adultos
---

# 25 g en adultos

#graphify/concept #graphify/EXTRACTED #community/dosis_letal_por_va_oral_de_lidocana__25_g_en_adultos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### dosis letal por vía oral de lidocaína → 25 g en adultos
Relación: es aproximadamente de · concepto conectado: [[dosis letal por vía oral de lidocaína|dosis letal por vía oral de lidocaína]]

> La dosis letal por vía oral de lidocaína es aproximadamente de 25 g en adultos.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `4c04d30cb48e81c30285c88c0c94a83f37bc0b6ec50d2e751e1abc3f9dbf5366`
Localizador: {"kind": "normalized_char_offsets", "start": 263619, "end": 265855}
