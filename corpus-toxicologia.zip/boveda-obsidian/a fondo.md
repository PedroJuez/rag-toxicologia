---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "metabolismo humano de las anfetaminas con anillo sustituido · a fondo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/metabolismo_humano_de_las_anfetaminas_con_anillo_sustituido__a_fondo
---

# a fondo

#graphify/concept #graphify/EXTRACTED #community/metabolismo_humano_de_las_anfetaminas_con_anillo_sustituido__a_fondo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### metabolismo humano de las anfetaminas con anillo sustituido → a fondo
Relación: no se ha estudiado · concepto conectado: [[metabolismo humano de las anfetaminas con anillo sustituido|metabolismo humano de las anfetaminas con anillo sustituido]]

> No se ha estudiado a fondo el metabolismo humano de las anfetaminas con anillo sustituido

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `dfc5f73e057ef576c791f0aaf088134fa8e18f95dd4ed39e713abef3d412b6e9`
Localizador: {"kind": "normalized_char_offsets", "start": 186281, "end": 188471}
