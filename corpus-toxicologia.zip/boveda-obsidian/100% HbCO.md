---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "(A₅₄₀/A₅₇₉ solución de y) = 1,5 · 100% HbCO"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/A/A_solucin_de_y__15__100_HbCO
---

# 100% HbCO

#graphify/concept #graphify/EXTRACTED #community/A/A_solucin_de_y__15__100_HbCO
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### (A₅₄₀/A₅₇₉ solución de y) = 1,5 → 100% HbCO
Relación: corresponde a · concepto conectado: [[(A₅₄₀A₅₇₉ solución de y) = 1,5|(A₅₄₀/A₅₇₉ solución de y) = 1,5]]

> (A₅₄₀/A₅₇₉ solución de y) = 1,5 correspondiendo a 100% HbCO.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `aa7c4307c5beaa7de35a737c81be3a8069bfdbe40ec558af649832e19c4be13c`
Localizador: {"kind": "normalized_char_offsets", "start": 289338, "end": 291614}
