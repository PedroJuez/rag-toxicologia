---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "tiocolina · 2-nitro-5-mercapto benzoato"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/tiocolina__2-nitro-5-mercapto_benzoato
---

# 2-nitro-5-mercapto benzoato

## Connections
- [[405nm]] - `puede medirse a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/tiocolina__2-nitro-5-mercapto_benzoato
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### tiocolina → 2-nitro-5-mercapto benzoato
Relación: reacciona con el ácido 5,5’-ditiobis-2-nitrobenzoíco (DTNB) produciendo · concepto conectado: [[tiocolina|tiocolina]]

> La tiocolina reacciona con el ácido 5,5’-ditiobis-2-nitrobenzoíco (DTNB) produciendo el 2-nitro-5-mercapto benzoato

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `c64674e2fc6176f586f799e93728966640618fad156293057e580e1fddbe9a36`
Localizador: {"kind": "normalized_char_offsets", "start": 331222, "end": 333452}

### 2-nitro-5-mercapto benzoato → 405nm
Relación: puede medirse a · concepto conectado: [[405nm|405nm]]

> 2-nitro-5-mercapto benzoato, compuesto coloreado que puede medirse a 405nm.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `c64674e2fc6176f586f799e93728966640618fad156293057e580e1fddbe9a36`
Localizador: {"kind": "normalized_char_offsets", "start": 331222, "end": 333452}
