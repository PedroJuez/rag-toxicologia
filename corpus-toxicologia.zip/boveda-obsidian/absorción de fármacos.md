---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Ingesta moderada · absorción de fármacos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Ingesta_moderada__absorcin_de_frmacos
---

# absorción de fármacos

#graphify/concept #graphify/EXTRACTED #community/Ingesta_moderada__absorcin_de_frmacos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Ingesta moderada → absorción de fármacos
Relación: aumenta · concepto conectado: [[Ingesta moderada|Ingesta moderada]]

> Ingesta moderada: Aumenta la absorción de fármacos

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `bf81a38131d6a0fc9beae86f28a128d395fb433b817fbcb4338b70f5fde2fd78`
Localizador: {"kind": "normalized_char_offsets", "start": 68144, "end": 70459}
