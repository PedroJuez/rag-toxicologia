---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "20-30% restante · nivel gástrico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/20-30_restante__nivel_gstrico
---

# 20-30% restante

## Connections
- [[nivel gástrico]] - `se absorbe a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/20-30_restante__nivel_gstrico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 20-30% restante → nivel gástrico
Relación: se absorbe a · concepto conectado: [[nivel gástrico|nivel gástrico]]

> A nivel gástrico se absorbe el 20-30% restante.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f964eef4f592ba598617ae72a5ba756a23df68d58eb86d4b51d9eeb457c90283`
Localizador: {"kind": "normalized_char_offsets", "start": 46278, "end": 48603}
