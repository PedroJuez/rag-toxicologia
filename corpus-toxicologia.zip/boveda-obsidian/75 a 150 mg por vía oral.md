---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "75 a 150 mg por vía oral · Etilcatinona"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/75_a_150_mg_por_va_oral__Etilcatinona
---

# 75 a 150 mg por vía oral

#graphify/concept #graphify/EXTRACTED #community/75_a_150_mg_por_va_oral__Etilcatinona
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Etilcatinona → 75 a 150 mg por vía oral
Relación: tiene dosis de · concepto conectado: [[Etilcatinona|Etilcatinona]]

> Etilcatinona : dosis de 75 a 150 mg por vía oral

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `c835b0ddf136f827ee396d4d014c7b0854922ca81efb49a065bf457255b17670`
Localizador: {"kind": "normalized_char_offsets", "start": 227900, "end": 230260}
