---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "THC · CEDIA"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/THC__CEDIA
---

# absorción de etanol

#graphify/concept #graphify/EXTRACTED #community/THC__CEDIA
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### THC → absorción de etanol
Relación: ralentiza · concepto conectado: [[THC|THC]]

> el THC ralentiza el vaciamiento gástrico, así como la absorción de etanol

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `1d498410ed2fdfa9dac4988beeb8394b915b849a9e5de40b0d682985f7afe396`
Localizador: {"kind": "normalized_char_offsets", "start": 165709, "end": 167977}
