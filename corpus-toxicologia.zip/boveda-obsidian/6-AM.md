---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "heroína · bhe"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/herona__bhe
---

# 6-AM

## Connections
- [[heroína]] - `es metabolito de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/herona__bhe
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 6-AM → heroína
Relación: es metabolito de · concepto conectado: [[heroína|heroína]]

> metabolito de heroína (6-AM)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `ca861fc921c32a40bf8edbe48558ee8eb57f2dc6c0b712f1d9a025c82cd5a116`
Localizador: {"kind": "normalized_char_offsets", "start": 141928, "end": 143365}
