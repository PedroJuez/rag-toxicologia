---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "(a) a (g) · cámaras de microdifusión"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/a_a_g__cmaras_de_microdifusin
---

# (a) a (g)

#graphify/concept #graphify/EXTRACTED #community/a_a_g__cmaras_de_microdifusin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### cámaras de microdifusión → (a) a (g)
Relación: se rotulan desde · concepto conectado: [[cámaras de microdifusión|cámaras de microdifusión]]

> **Testigos:** Solución patrón de cianuro. Disolver 50 mg de cianuro de potasio en 100 ml de solución acuosa de hidróxido de sodio (0,1 mol/l). Concentración del ión de cianuro: 200 mg/l. **Tener precaución cuando se usan soluciones de cianuro.** Solución de calibración de cianuro: Diluir (1:99) la solución patrón del ión cianuro (200 mg/l) en solución acuosa de hidróxido de sodio (0,1 mol/l); obteniéndose una solución de concentración de ión cianuro de 2 mg/l. **Procedimiento:** Rotular siete cámaras de microdifusión desde (a) a (g) y agregar en el **compartimiento** **exterior** de la cámara, los reactivos de acuerdo a lo que indica la tabla que se detalla mas adelante, y el ácido sulfúrico diluído en el lado opuesto de la misma, cuidando no mezclar patrones o muestras con el reactivo liberante (ácido sulfúrico diluído) antes de tapar la cámara. Agregar 2 ml de solución del hidróxido de sodio al **compartimiento interno**. Se tapa cada cámara usando silicona y cuidadosamente se mezclan los componentes de la parte externa y se dejan a temperatura ambiente durante 4 horas. Pipetear 1,0 ml de la solución del hidróxido de sodio de cada uno de los compartimentos internos y transvasarlos a tubos rotulados. Agregar los reactivos siguientes secuencialmente y agitar para mezclarlos. -2 ml de Buffer fosfato -1 ml de solución de cloramina T -3 ml de reactivo piridina-ácido barbitúrico.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f8e378d1989e16a8e697346bb2d3ca9652f75a6b504149744eae008dea7a681f`
Localizador: {"kind": "normalized_char_offsets", "start": 186268, "end": 188363}
