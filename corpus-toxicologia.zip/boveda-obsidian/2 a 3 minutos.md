---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "heroína · bhe"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/herona__bhe
---

# 2 a 3 minutos

#graphify/concept #graphify/EXTRACTED #community/herona__bhe
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### heroína → 2 a 3 minutos
Relación: tiene un período de semidesintegración de · concepto conectado: [[heroína|heroína]]

> presencia de heroína directamente en los fluidos biológicos humanos (período de semidesintegración: 2 a 3 minutos [18])

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `3589e8ed20298b98a871d647d3d53feac22457038cf00c752877392514ce06c6`
Localizador: {"kind": "normalized_char_offsets", "start": 58337, "end": 60400}
