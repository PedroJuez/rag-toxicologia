---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "herbicidas clorofenoxi más comunes · 2,4-D (2,4-ácido diclorofenoxiacético)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/herbicidas_clorofenoxi_ms_comunes__24-D_24-cido_diclorofenoxiactico
---

# 2,4-D (2,4-ácido diclorofenoxiacético)

#graphify/concept #graphify/EXTRACTED #community/herbicidas_clorofenoxi_ms_comunes__24-D_24-cido_diclorofenoxiactico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### herbicidas clorofenoxi más comunes → 2,4-D (2,4-ácido diclorofenoxiacético)
Relación: incluyen · concepto conectado: [[herbicidas clorofenoxi más comunes|herbicidas clorofenoxi más comunes]]

> Los herbicidas clorofenoxi más comunes son: 2,4-D (2,4-ácido diclorofenoxiacético)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `ba9635ad5aa579e0159cf9beda1b0d7a2a3a5545f4fe73d9feb4f235cea73103`
Localizador: {"kind": "normalized_char_offsets", "start": 196723, "end": 199030}
