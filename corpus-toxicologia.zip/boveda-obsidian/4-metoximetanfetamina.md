---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "PMMA · listas anexas al Convenio sobre Sustancias Sicotrópicas de 1971"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/PMMA__listas_anexas_al_Convenio_sobre_Sustancias_Sicotrpicas_de_1971
---

# 4-metoximetanfetamina

## Connections
- [[PMMA]] - `es abreviado o conocido como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/PMMA__listas_anexas_al_Convenio_sobre_Sustancias_Sicotrpicas_de_1971
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 4-metoximetanfetamina → PMMA
Relación: es abreviado o conocido como · concepto conectado: [[PMMA|PMMA]]

> |4-metoximetanfetamina|PMMA|

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `a16d7facd34189e42dbfdaf6b471a247f3ad3bd5502b14c7d9e2fb83927f4155`
Localizador: {"kind": "normalized_char_offsets", "start": 184277, "end": 186281}
