---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "absorción de un tóxico · paso desde el lugar de administración hasta el plasma/ corriente circulatoria"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorcin_de_un_txico__paso_desde_el_lugar_de_administracin_hasta_el_plasma/_corriente_circulatoria
---

# absorción de un tóxico

## Connections
- [[paso desde el lugar de administración hasta el plasma corriente circulatoria]] - `es` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorcin_de_un_txico__paso_desde_el_lugar_de_administracin_hasta_el_plasma/_corriente_circulatoria
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorción de un tóxico → paso desde el lugar de administración hasta el plasma/ corriente circulatoria
Relación: es · concepto conectado: [[paso desde el lugar de administración hasta el plasma corriente circulatoria|paso desde el lugar de administración hasta el plasma/ corriente circulatoria]]

> La absorción de un tóxico es el paso desde el lugar de administración hasta el plasma/ corriente circulatoria.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f78a5cad21f456678ea7a0ceb1315bdec7603bc717288d2aa640814a78e76af4`
Localizador: {"kind": "normalized_char_offsets", "start": 327692, "end": 330041}
