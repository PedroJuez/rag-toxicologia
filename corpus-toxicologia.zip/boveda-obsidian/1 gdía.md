---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "1 g/día · consumidores habituales"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_g/da__consumidores_habituales
---

# 1 g/día

#graphify/concept #graphify/EXTRACTED #community/1_g/da__consumidores_habituales
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### consumidores habituales → 1 g/día
Relación: pueden llegan hasta · concepto conectado: [[consumidores habituales|consumidores habituales]]

> consumidores habituales pueden llegan hasta 1 g/día.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `c835b0ddf136f827ee396d4d014c7b0854922ca81efb49a065bf457255b17670`
Localizador: {"kind": "normalized_char_offsets", "start": 227900, "end": 230260}
