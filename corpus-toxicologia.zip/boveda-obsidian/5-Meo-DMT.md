---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "5-Meo-DMT · menos de media hora"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/5-Meo-DMT__menos_de_media_hora
---

# 5-Meo-DMT

## Connections
- [[menos de media hora]] - `es de corta duración` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/5-Meo-DMT__menos_de_media_hora
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 5-Meo-DMT → menos de media hora
Relación: es de corta duración · concepto conectado: [[menos de media hora|menos de media hora]]

> De corta duración (menos de media hora): 5-Meo-DMT

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `004e97872208fba79a3b40cafaee3a80b9854266a3414685b8c446ce15ae48fa`
Localizador: {"kind": "normalized_char_offsets", "start": 300591, "end": 302925}
