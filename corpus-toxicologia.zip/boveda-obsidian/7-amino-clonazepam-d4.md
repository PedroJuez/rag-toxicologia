---
source_file: "6063972895f0ee635dfe940329b5666d9be5c3e5c39e7652596dac33e16e4eb9.md"
type: "concept"
community: "efedrina · Bromazepan"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/efedrina__Bromazepan
---

# 7-amino-clonazepam-d4

#graphify/concept #graphify/EXTRACTED #community/efedrina__Bromazepan
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Bromazepan → 7-amino-clonazepam-d4
Relación: tiene estándar interno · concepto conectado: [[Bromazepan|Bromazepan]]

> |Bromazepan|316 → 182|7-amino-clonazepam-d4|

Fuente: analisisdrogasabuso.pdf
Fragmento: `f873b4b7ca8bbb6b0ae3aaa329ab4578a693af74ac3656443dee9f25944c9b22`
Localizador: {"kind": "normalized_char_offsets", "start": 21798, "end": 24130}
