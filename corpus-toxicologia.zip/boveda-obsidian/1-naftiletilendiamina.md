---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "diazo compuestos · 1-naftiletilendiamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/diazo_compuestos__1-naftiletilendiamina
---

# 1-naftiletilendiamina

#graphify/concept #graphify/EXTRACTED #community/diazo_compuestos__1-naftiletilendiamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### diazo compuestos → 1-naftiletilendiamina
Relación: se unen con · concepto conectado: [[diazo compuestos|diazo compuestos]]

> diazo compuestos con el ácido nitroso los cuales se unen con 1-naftiletilendiamina

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `70084b55f20a849d88b643e4e36c64e4248b92c7bad32c8d4d9bcc1c6ea71d0c`
Localizador: {"kind": "normalized_char_offsets", "start": 102485, "end": 104752}
