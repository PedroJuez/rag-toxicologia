---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Barbitúricos · color violeta"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Barbitricos__color_violeta
---

# 5,5'-disubstituído del ácido barbitúrico

#graphify/concept #graphify/EXTRACTED #community/Barbitricos__color_violeta
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Barbitúricos → 5,5'-disubstituído del ácido barbitúrico
Relación: son derivados del · concepto conectado: [[Barbitúricos|Barbitúricos]]

> Los barbitúricos son derivados del 5,5'-disubstituído del ácido barbitúrico.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `cde098693c2b903147a47ea546d7397158e1a4871ce97dc489135c51b4fbb27e`
Localizador: {"kind": "normalized_char_offsets", "start": 127031, "end": 129330}
