---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Solución acuosa de cianuro de potasio (10 mg/l) · 4 mg/l de ión de cianuro"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Solucin_acuosa_de_cianuro_de_potasio_10_mg/l__4_mg/l_de_in_de_cianuro
---

# 4 mg/l de ión de cianuro

#graphify/concept #graphify/EXTRACTED #community/Solucin_acuosa_de_cianuro_de_potasio_10_mg/l__4_mg/l_de_in_de_cianuro
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Solución acuosa de cianuro de potasio (10 mg/l) → 4 mg/l de ión de cianuro
Relación: corresponde a · concepto conectado: [[Solución acuosa de cianuro de potasio (10 mgl)|Solución acuosa de cianuro de potasio (10 mg/l)]]

> Solución acuosa de hidróxido de sodio (0,5 mol/l). Solución acuosa de ácido sulfúrico (3,6 mol/l). p-nitrobenzaldehído (0,05 mol/l) en 2-metoxietanol. o-dinitrobenceno (0,05 mol/l) en 2-metoxietanol. **Testigos:** Solución acuosa de cianuro de potasio (10 mg/l, correspondiente a 4 mg/l de ión de cianuro). **Procedimiento:** Tomar tres cámaras de microdifusión y agregar a cada una en el compartimiento central: § 0,5 ml de solución del p-nitrobenzaldehído. § 0,5 ml de solución del o-dinitrobenceno. § 0,1 ml de solución del hidróxido de sodio. En el compartimiento exterior agregar 0,1 ml de: § Cámara Nº 1 Agua destilada § Cámara Nº 2 Solución patrón de cianuro de potasio § Cámara Nº 3 Muestra de sangre problema A cada cámara en la parte exterior agregar 0,5 ml de agua destilada y en el lado opuesto, 1,0 ml de ácido sulfúrico diluído. Se tapa cada cámara usando silicona y cuidadosamente se mezclan los componentes del compartimiento externo. Incubar a temperatura ambiente durante 20 minutos y agregar 1 ml de solución acuosa de metanol (1:1) en el compartimiento interno. Transferir el contenido del compartimiento interno de la cámara a un tubo graduado de 5,0 ml y llevar a volumen (5 ml) con solución acuosa de metanol (1:1)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `13dfa64012917cfe4e1e8111e70296db1b44add6f179d90f028e6ec720fc11be`
Localizador: {"kind": "normalized_char_offsets", "start": 184130, "end": 186268}
