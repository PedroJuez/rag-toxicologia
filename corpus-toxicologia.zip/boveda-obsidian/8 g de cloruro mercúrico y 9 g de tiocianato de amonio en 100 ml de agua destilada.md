---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Reactivo de mercuritiocianato de amonio · 8 g de cloruro mercúrico y 9 g de tiocianato de amonio en 100 ml de agua destilada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Reactivo_de_mercuritiocianato_de_amonio__8_g_de_cloruro_mercrico_y_9_g_de_tiocianato_de_amonio_en_100_ml_de_agua_destilada
---

# 8 g de cloruro mercúrico y 9 g de tiocianato de amonio en 100 ml de agua destilada

#graphify/concept #graphify/EXTRACTED #community/Reactivo_de_mercuritiocianato_de_amonio__8_g_de_cloruro_mercrico_y_9_g_de_tiocianato_de_amonio_en_100_ml_de_agua_destilada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Reactivo de mercuritiocianato de amonio → 8 g de cloruro mercúrico y 9 g de tiocianato de amonio en 100 ml de agua destilada
Relación: se prepara al mezclar · concepto conectado: [[Reactivo de mercuritiocianato de amonio|Reactivo de mercuritiocianato de amonio]]

> Reactivo de mercuritiocianato de amonio. Mezclar 8 g de cloruro mercúrico y 9 g de tiocianato de amonio en 100 ml de agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `82bbc170626aee620c0d102070933d1fcb059696299ec91b38230d488d71ca39`
Localizador: {"kind": "normalized_char_offsets", "start": 200897, "end": 203137}
