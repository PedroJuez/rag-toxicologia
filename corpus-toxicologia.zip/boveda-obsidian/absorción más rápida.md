---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "bebidas con gas carbónico (como el cava) o combinados · absorción más rápida"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/bebidas_con_gas_carbnico_como_el_cava_o_combinados__absorcin_ms_rpida
---

# absorción más rápida

#graphify/concept #graphify/EXTRACTED #community/bebidas_con_gas_carbnico_como_el_cava_o_combinados__absorcin_ms_rpida
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### bebidas con gas carbónico (como el cava) o combinados → absorción más rápida
Relación: presentan · concepto conectado: [[bebidas con gas carbónico (como el cava) o combinados|bebidas con gas carbónico (como el cava) o combinados]]

> bebidas con gas carbónico (como el cava) o combinados, presentan una absorción más rápida

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f964eef4f592ba598617ae72a5ba756a23df68d58eb86d4b51d9eeb457c90283`
Localizador: {"kind": "normalized_char_offsets", "start": 46278, "end": 48603}
