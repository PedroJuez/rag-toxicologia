---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "10 minutos · solución"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/10_minutos__solucin
---

# 10 minutos

#graphify/concept #graphify/EXTRACTED #community/10_minutos__solucin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### solución → 10 minutos
Relación: se extrae por agitación durante · concepto conectado: [[solución|solución]]

> se extrae la solución por agitación durante 10 minutos

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `203592cccc96c3cf217db325edf2817f8824f1444a30c7570827b0e9d294a4c1`
Localizador: {"kind": "normalized_char_offsets", "start": 114129, "end": 116384}
