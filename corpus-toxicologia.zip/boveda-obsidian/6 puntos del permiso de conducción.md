---
source_file: "d9bbc99393f878a02d48dc7923372b0485a2c142547eac8725aea930d645d5f2.md"
type: "concept"
community: "Infracción muy grave según artículo 65 LSV · 6 puntos del permiso de conducción"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Infraccin_muy_grave_segn_artculo_65_LSV__6_puntos_del_permiso_de_conduccin
---

# 6 puntos del permiso de conducción

#graphify/concept #graphify/EXTRACTED #community/Infraccin_muy_grave_segn_artculo_65_LSV__6_puntos_del_permiso_de_conduccin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Infracción muy grave según artículo 65 LSV → 6 puntos del permiso de conducción
Relación: sanciona con pérdida de · concepto conectado: [[Infracción muy grave según artículo 65 LSV|Infracción muy grave según artículo 65 LSV]]

> Infracción muy grave según artículo 65 LSV[14]:
> - Multa: 1.000 euros
> - Pérdida de puntos: 6 puntos del permiso de conducción

Fuente: Toxicología Etanol Drogas.pdf
Fragmento: `8727082738b1362436cb12e87a57331906b15b8d856edea62795f0b1ba3dea6a`
Localizador: {"kind": "normalized_char_offsets", "start": 6262, "end": 8439}
