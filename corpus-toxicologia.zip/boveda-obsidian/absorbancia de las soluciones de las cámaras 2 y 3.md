---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "absorbancia de las soluciones de las cámaras 2 y 3 · 560 nm"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorbancia_de_las_soluciones_de_las_cmaras_2_y_3__560_nm
---

# absorbancia de las soluciones de las cámaras 2 y 3

## Connections
- [[560 nm]] - `se mide a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorbancia_de_las_soluciones_de_las_cmaras_2_y_3__560_nm
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbancia de las soluciones de las cámaras 2 y 3 → 560 nm
Relación: se mide a · concepto conectado: [[560 nm|560 nm]]

> **Resultados**: El color rojo obtenido con las soluciones que contienen cianuro son estables durante aproximadamente 15 minutos. Medir la absorbancia de las soluciones de las cámaras 2 y 3 a 560 nm contra blanco de agua destilada (cámara Nº 1). Calcular la concentración del ión cianuro en la muestra utilizando la concentración y la absorbancia obtenida del patrón. **Sensibilidad:** 0,5 mg/l.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `13dfa64012917cfe4e1e8111e70296db1b44add6f179d90f028e6ec720fc11be`
Localizador: {"kind": "normalized_char_offsets", "start": 184130, "end": 186268}
