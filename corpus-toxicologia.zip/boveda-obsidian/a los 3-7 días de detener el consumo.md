---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Síndrome de abstinencia · apatía"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Sndrome_de_abstinencia__apata
---

# a los 3-7 días de detener el consumo

#graphify/concept #graphify/EXTRACTED #community/Sndrome_de_abstinencia__apata
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Síndrome de abstinencia → a los 3-7 días de detener el consumo
Relación: puede desarrollarse · concepto conectado: [[Síndrome de abstinencia|Síndrome de abstinencia]]

> Puede desarrollarse un síndrome de abstinencia a los 3-7 días de detener el consumo

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `4a7037690a28c08c1913508471d0478d4e2066373e3b13f9804875aea1b0e395`
Localizador: {"kind": "normalized_char_offsets", "start": 158816, "end": 161135}
