---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "estabilidad de los reactivos · 6 meses conservados en heladera a 4º C"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/estabilidad_de_los_reactivos__6_meses_conservados_en_heladera_a_4_C
---

# 6 meses conservados en heladera a 4º C

#graphify/concept #graphify/EXTRACTED #community/estabilidad_de_los_reactivos__6_meses_conservados_en_heladera_a_4_C
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### estabilidad de los reactivos → 6 meses conservados en heladera a 4º C
Relación: es de · concepto conectado: [[estabilidad de los reactivos|estabilidad de los reactivos]]

> **Muestra:** Plasma (anticoagulante:EDTA) o suero. Evitar la utilización de heparina como anticoagulante. Conservar a 4º C cuando no se realice el análisis en forma inmediata. **Reactivos:** Solución de TPTz (2,4,6-tris (2-piridil)s-triazine) 8 mM : Disolver 74,88 mg de droga sólida de TPTz en 30 ml de HCl 0,036 M. Conservar en frasco color caramelo. Solución de HCl 0,036 M: Tomar 155 µL de HCl concentrado y llevar a 50 ml. Solución de Cloruro Férrico 0,54 %: Disolver 54 mg de Fe(NO₃)3.9H₂O en 10 ml de HCl 0,02M.Conservar en frasco color caramelo. Solución de HCl 0,020 M: Tomar 0,86 ml de HCl concentrado y llevar a 500 ml con agua destilada. Solución Buffer de Acetato de Sodio 0,3M (pH 3,6): Disolver 467,35 mg de Acetato de Sodio Anhidro en 200 ml de agua destilada y adicionar 4 ml de Acido Acético Glacial. Ajustar a pH 3,6. Llevar a volumen final de 250 ml. Estabilidad de los reactivos: es de 6 meses conservados en heladera a 4º C. **Testigos:** Solución Madre de Paracetamol 1 mg/ml: Disolver 10 mg de droga pura en 10 ml de agua destilada. Conservar en frasco color caramelo. Testigos de Paracetamol 50; 100; 150; 200 y 250 mg/ml: Tomar 0,5; 1,0; 1,5; 2,0 y 2,5 ml de solución madre, colocarlos en respectivos matraces de 10 ml y llevar a volumen con agua destilada. Conservar en frasco color caramelo.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `5e90ee03c8a1cbf03778393e3ad71dd5c9fb96a4d231c8ff2a992c1bc764c680`
Localizador: {"kind": "normalized_char_offsets", "start": 318414, "end": 320800}
