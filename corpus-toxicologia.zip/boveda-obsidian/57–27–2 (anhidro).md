---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Morfina · anticuerpos de los módulos de inmunoanálisis comerciales"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Morfina__anticuerpos_de_los_mdulos_de_inmunoanlisis_comerciales
---

# 57–27–2 (anhidro)

#graphify/concept #graphify/EXTRACTED #community/Morfina__anticuerpos_de_los_mdulos_de_inmunoanlisis_comerciales
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Morfina → 57–27–2 (anhidro)
Relación: tiene N° CAS · concepto conectado: [[Morfina|Morfina]]

> N° CAS**:** 57–27–2 (anhidro)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `18b51a20dbd287e58db0b08d552772b688745473375370ead6f0edf76d9ee993`
Localizador: {"kind": "normalized_char_offsets", "start": 294014, "end": 296174}
