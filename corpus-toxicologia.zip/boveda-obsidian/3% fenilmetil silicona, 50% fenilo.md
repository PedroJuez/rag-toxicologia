---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "OV-17 · 3% fenilmetil silicona, 50% fenilo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/OV-17__3_fenilmetil_silicona_50_fenilo
---

# 3% fenilmetil silicona, 50% fenilo

## Connections
- [[OV-17]] - `se identifica como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/OV-17__3_fenilmetil_silicona_50_fenilo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3% fenilmetil silicona, 50% fenilo → OV-17
Relación: se identifica como · concepto conectado: [[OV-17|OV-17]]

> *b) 3% f*enilmetil silicona, 50% fenilo (OV-17)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `50b815806788b515c1c29df59522e48e10a93978198d6eae2c261746a4a50750`
Localizador: {"kind": "normalized_char_offsets", "start": 122528, "end": 124903}
