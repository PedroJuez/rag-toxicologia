---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "4 g de NaOH · NaOH 1N (4%)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/4_g_de_NaOH__NaOH_1N_4
---

# 4 g de NaOH

#graphify/concept #graphify/EXTRACTED #community/4_g_de_NaOH__NaOH_1N_4
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### NaOH 1N (4%) → 4 g de NaOH
Relación: se prepara con · concepto conectado: [[NaOH 1N (4%)|NaOH 1N (4%)]]

> NaOH 1N (4%): disolver 4 g de NaOH llevando a 100 ml con agua destilada.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
