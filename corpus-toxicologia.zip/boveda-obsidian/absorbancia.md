---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "absorbancia · 520 nm"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorbancia__520_nm
---

# absorbancia

## Connections
- [[520 nm]] - `se determina a` [EXTRACTED]
- [[587 nm]] - `se mide a` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorbancia__520_nm
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbancia → 587 nm
Relación: se mide a · concepto conectado: [[587 nm|587 nm]]

> absorbancia a 587 nm de cada solución contra los blancos de agua

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}

### absorbancia → 520 nm
Relación: se determina a · concepto conectado: [[520 nm|520 nm]]

> Se determina la absorbancia a 520 nm contra un blanco de reactivos

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f5ec2488a5dbd4697179229045625ed7c3900da1b4c340c5775b6f96520c17a8`
Localizador: {"kind": "normalized_char_offsets", "start": 190330, "end": 192499}
