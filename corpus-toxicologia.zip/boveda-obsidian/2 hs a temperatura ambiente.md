---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "2 hs a temperatura ambiente · sangre u orina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/2_hs_a_temperatura_ambiente__sangre_u_orina
---

# 2 hs a temperatura ambiente

#graphify/concept #graphify/EXTRACTED #community/2_hs_a_temperatura_ambiente__sangre_u_orina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### sangre u orina → 2 hs a temperatura ambiente
Relación: tiene tiempo de difusión de · concepto conectado: [[sangre u orina|sangre u orina]]

> Tiempo de difusión: 2 hs a temperatura ambiente para sangre u orina

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3e68d3c8a603dde4c80641d01107fdc69ae5d5a2452c0bed8dc04b31a1912309`
Localizador: {"kind": "normalized_char_offsets", "start": 275654, "end": 277772}
