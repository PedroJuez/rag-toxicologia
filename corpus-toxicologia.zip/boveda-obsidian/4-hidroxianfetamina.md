---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "PMA · P-metoxiamfetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/PMA__P-metoxiamfetamina
---

# 4-hidroxianfetamina

#graphify/concept #graphify/EXTRACTED #community/PMA__P-metoxiamfetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### PMA → 4-hidroxianfetamina
Relación: tiene como metabolito en humanos a · concepto conectado: [[PMA|PMA]]

> |PMA|Humanos|PMA|4-hidroxianfetamina|147|

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `dfc5f73e057ef576c791f0aaf088134fa8e18f95dd4ed39e713abef3d412b6e9`
Localizador: {"kind": "normalized_char_offsets", "start": 186281, "end": 188471}
