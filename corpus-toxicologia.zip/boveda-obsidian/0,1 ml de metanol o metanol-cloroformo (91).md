---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "residuo · 0,1 ml de metanol o metanol-cloroformo (9:1)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
---

# 0,1 ml de metanol o metanol-cloroformo (9:1)

#graphify/concept #graphify/EXTRACTED #community/residuo__01_ml_de_metanol_o_metanol-cloroformo_91
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### residuo → 0,1 ml de metanol o metanol-cloroformo (9:1)
Relación: se vuelve a disolver en · concepto conectado: [[residuo|residuo]]

> Volver a disolver el residuo en 0,1 ml de metanol o metanol-cloroformo (9:1) para efectuar el análisis de CCD o CG.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `8f6d7c86b8bcf9608bb6f9e40790ba8c2e38e7b2cdb1fe80d0442a87bb6a86ee`
Localizador: {"kind": "normalized_char_offsets", "start": 60400, "end": 62610}
