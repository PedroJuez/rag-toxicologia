---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "4- methoxyamphetamine · hallucinogen"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/4-_methoxyamphetamine__hallucinogen
---

# 4- methoxyamphetamine

## Connections
- [[hallucinogen]] - `es` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/4-_methoxyamphetamine__hallucinogen
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 4- methoxyamphetamine → hallucinogen
Relación: es · concepto conectado: [[hallucinogen|hallucinogen]]

> hallucinogen 4- methoxyamphetamine

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `5a1cdaddd707042eb08d451200409dec266acbb95499d9146b045edbc3bdcfca`
Localizador: {"kind": "normalized_char_offsets", "start": 232303, "end": 234542}
