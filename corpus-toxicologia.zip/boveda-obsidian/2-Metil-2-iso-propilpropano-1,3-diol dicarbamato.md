---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "meprobamato · C₉H₁₈N₂O₄"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/meprobamato__CHNO
---

# 2-Metil-2-iso-propilpropano-1,3-diol dicarbamato

#graphify/concept #graphify/EXTRACTED #community/meprobamato__CHNO
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### meprobamato → 2-Metil-2-iso-propilpropano-1,3-diol dicarbamato
Relación: tiene sinónimo · concepto conectado: [[meprobamato|meprobamato]]

> Sinónimos: 2-Metil-2-iso-propilpropano-1,3-diol dicarbamato

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `4c04d30cb48e81c30285c88c0c94a83f37bc0b6ec50d2e751e1abc3f9dbf5366`
Localizador: {"kind": "normalized_char_offsets", "start": 263619, "end": 265855}
