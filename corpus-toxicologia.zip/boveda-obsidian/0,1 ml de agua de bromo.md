---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "compartimiento interno · reactivo fijador"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/compartimiento_interno__reactivo_fijador
---

# 0,1 ml de agua de bromo

## Connections
- [[compartimiento interno]] - `se agrega en el` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/compartimiento_interno__reactivo_fijador
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 0,1 ml de agua de bromo → compartimiento interno
Relación: se agrega en el · concepto conectado: [[compartimiento interno|compartimiento interno]]

> agregar en el compartimiento interno 0,1 ml de agua de bromo

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f5ec2488a5dbd4697179229045625ed7c3900da1b4c340c5775b6f96520c17a8`
Localizador: {"kind": "normalized_char_offsets", "start": 190330, "end": 192499}
