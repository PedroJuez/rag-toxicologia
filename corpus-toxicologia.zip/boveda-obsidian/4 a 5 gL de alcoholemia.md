---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "estado de coma · 4 a 5 g/L de alcoholemia"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/estado_de_coma__4_a_5_g/L_de_alcoholemia
---

# 4 a 5 g/L de alcoholemia

#graphify/concept #graphify/EXTRACTED #community/estado_de_coma__4_a_5_g/L_de_alcoholemia
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### estado de coma → 4 a 5 g/L de alcoholemia
Relación: suele aparecer entre · concepto conectado: [[estado de coma|estado de coma]]

> |>3 g/L >300 mg/dL >65.12 mmol/L 4-9 g/L 400-900 mg/dL >86.82 mmol/L Tabla 4. ansiolíticos y anestésicos.||en personas que no beben habitualmente. Relación entre etanolemia y sintomatología clínica, resumen de diversas fuentes bibliográficas consultadas. Hay que tener en cuenta que, cuando se ha desarrollado neuroadaptación y tolerancia al alcohol por consumo crónico, el cuadro desarrollado a igualdad de concentración de etanol en sangre es diferente, y se disminuyen los efectos motores, sedantes, Además de actuar como droga psicotrópica, el etanol es un tóxico celular cuyo consumo produce alteraciones multiorgánicas y daños irreversibles orgánicos que incrementan la morbimortalidad. Se incluyen síntomas como rubor facial, dolor abdominal, sangrado interno a nivel estomacal e intestinal, vómitos... Además, el riesgo de sufrir TCE y hematoma subdural es más del doble, y aumenta el riesgo de convulsiones, intentos autolíticos e intoxicaciones combinadas. La muerte puede aparecer también por aspiración de vómito, por coma cetoacidótico e hipoglucémico y por hipotermia. Dependencia física Dependencia psíquica Tolerancia Sd de abstinencia|Anestesia casi completa, ausencia de percepción y confusión. Generalmente produce coma, además de hipotensión y de hipotermia (favorecida por la vasodilatación cutánea y sensación de calor, con aumento de la pérdida calórica y también pérdida del termostato central de la temperatura) El estado de coma suele aparecer entre los 4 a 5 g/L de alco- holemia en que la depresión bulbar conducirá al paro respi- ratorio y puede constituir una causa de muerte por sí misma. Sí Sí Sí Sí||

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `c454ec588aee7a76eb9aad64421376578a6add58003d2a0ad9166cf900eb9aef`
Localizador: {"kind": "normalized_char_offsets", "start": 56612, "end": 58953}
