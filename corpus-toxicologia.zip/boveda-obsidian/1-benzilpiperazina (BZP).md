---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "DMT · fiscalización internacional"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/DMT__fiscalizacin_internacional
---

# 1-benzilpiperazina (BZP)

## Connections
- [[Droga]] - `es consumida habitualmente como` [EXTRACTED]
- [[fiscalización internacional]] - `se encuentra bajo` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/DMT__fiscalizacin_internacional
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1-benzilpiperazina (BZP) → Droga
Relación: es consumida habitualmente como · concepto conectado: [[Droga|Droga]]

> Una de las piperazinas consumida habitualmente como droga es la 1-benzilpiperazina (BZP)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f638b6fe87e09c49b9e305bff142484c97e015053a52937ad9d2f8134404ce92`
Localizador: {"kind": "normalized_char_offsets", "start": 274150, "end": 276533}

### 1-benzilpiperazina (BZP) → fiscalización internacional
Relación: se encuentra bajo · concepto conectado: [[fiscalización internacional|fiscalización internacional]]

> la 1-benzilpiperazina (BZP), que se encuentra bajo fiscalización internacional.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `f638b6fe87e09c49b9e305bff142484c97e015053a52937ad9d2f8134404ce92`
Localizador: {"kind": "normalized_char_offsets", "start": 274150, "end": 276533}
