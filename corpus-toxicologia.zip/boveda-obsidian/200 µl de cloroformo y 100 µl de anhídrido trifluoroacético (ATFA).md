---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "200 µl de cloroformo y 100 µl de anhídrido trifluoroacético (ATFA) · residuo del eluyente evaporado (N₂, 50 a 60ºC)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/200_l_de_cloroformo_y_100_l_de_anhdrido_trifluoroactico_ATFA__residuo_del_eluyente_evaporado_N_50_a_60C
---

# 200 µl de cloroformo y 100 µl de anhídrido trifluoroacético (ATFA)

#graphify/concept #graphify/EXTRACTED #community/200_l_de_cloroformo_y_100_l_de_anhdrido_trifluoroactico_ATFA__residuo_del_eluyente_evaporado_N_50_a_60C
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### residuo del eluyente evaporado (N₂, 50 a 60ºC) → 200 µl de cloroformo y 100 µl de anhídrido trifluoroacético (ATFA)
Relación: se reconstituye con · concepto conectado: [[residuo del eluyente evaporado (N₂, 50 a 60ºC)|residuo del eluyente evaporado (N₂, 50 a 60ºC)]]

> El residuo del eluyente evaporado (N₂, 50 a 60ºC) se reconstituye con 200 µl de cloroformo y 100 µl de anhídrido trifluoroacético (ATFA)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `f94e3c69fe8599040d5a16ad06484a398038f8d089d99d4160318f0ad8167379`
Localizador: {"kind": "normalized_char_offsets", "start": 73934, "end": 76305}
