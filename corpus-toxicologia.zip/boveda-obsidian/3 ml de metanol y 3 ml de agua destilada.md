---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "columna de extracción en fase sólida (Bond-Elut Certify) · 3 ml de metanol y 3 ml de agua destilada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/columna_de_extraccin_en_fase_slida_Bond-Elut_Certify__3_ml_de_metanol_y_3_ml_de_agua_destilada
---

# 3 ml de metanol y 3 ml de agua destilada

#graphify/concept #graphify/EXTRACTED #community/columna_de_extraccin_en_fase_slida_Bond-Elut_Certify__3_ml_de_metanol_y_3_ml_de_agua_destilada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### columna de extracción en fase sólida (Bond-Elut Certify) → 3 ml de metanol y 3 ml de agua destilada
Relación: es acondicionada previamente con · concepto conectado: [[columna de extracción en fase sólida (Bond-Elut Certify)|columna de extracción en fase sólida (Bond-Elut Certify)]]

> columna de extracción en fase sólida (Bond-Elut Certify) acondicionada previamente con 3 ml de metanol y 3 ml de agua destilada

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `f94e3c69fe8599040d5a16ad06484a398038f8d089d99d4160318f0ad8167379`
Localizador: {"kind": "normalized_char_offsets", "start": 73934, "end": 76305}
