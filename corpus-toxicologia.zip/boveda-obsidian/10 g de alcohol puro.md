---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "unidad de bebida estándar (UBE) · valorar el riesgo del consumo a las personas"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/unidad_de_bebida_estndar_UBE__valorar_el_riesgo_del_consumo_a_las_personas
---

# 10 g de alcohol puro

## Connections
- [[unidad de bebida estándar (UBE)]] - `corresponden a lo que se denomina` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/unidad_de_bebida_estndar_UBE__valorar_el_riesgo_del_consumo_a_las_personas
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 10 g de alcohol puro → unidad de bebida estándar (UBE)
Relación: corresponden a lo que se denomina · concepto conectado: [[unidad de bebida estándar (UBE)|unidad de bebida estándar (UBE)]]

> 10 g de alcohol puro corresponden a lo que se denomina una unidad de bebida estándar (UBE)

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `a14aff8236c33e8ff23a1a52788eb00d1eff2e276e14e75b0ac4a4f673505b2d`
Localizador: {"kind": "normalized_char_offsets", "start": 44652, "end": 46278}
