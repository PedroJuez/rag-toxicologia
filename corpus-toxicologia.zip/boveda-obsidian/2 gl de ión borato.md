---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "0,210 g de ácido bórico en 100 ml de agua · 2 g/l de ión borato"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/0210_g_de_cido_brico_en_100_ml_de_agua__2_g/l_de_in_borato
---

# 2 g/l de ión borato

#graphify/concept #graphify/EXTRACTED #community/0210_g_de_cido_brico_en_100_ml_de_agua__2_g/l_de_in_borato
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 0,210 g de ácido bórico en 100 ml de agua → 2 g/l de ión borato
Relación: equivalente a · concepto conectado: [[0,210 g de ácido bórico en 100 ml de agua|0,210 g de ácido bórico en 100 ml de agua]]

> Disolver 0,210 g de ácido bórico en 100 ml de agua (equivalente a 2 g/l de ión borato)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `0520c27ce6dc319d06d699f14f2979019f03dd2a3e174049982b9837b8149e4c`
Localizador: {"kind": "normalized_char_offsets", "start": 157252, "end": 159608}
