---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Sensibilidad · Fósforo, 1 g/l"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Sensibilidad__Fsforo_1_g/l
---

# 0,2 mg/l

#graphify/concept #graphify/EXTRACTED #community/Sensibilidad__Fsforo_1_g/l
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Sensibilidad → 0,2 mg/l
Relación: es de · concepto conectado: [[Sensibilidad|Sensibilidad]]

> **Sensibilidad:** 0,2 mg/l.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `3ce10d50eac6ded0718bc4928e3ed5e762611bcdf142ca139cb2d9b05dc85eaf`
Localizador: {"kind": "normalized_char_offsets", "start": 188363, "end": 190330}
