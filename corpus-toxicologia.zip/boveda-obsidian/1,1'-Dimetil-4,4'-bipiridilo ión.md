---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "paraquat · pentaclorofenol"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/paraquat__pentaclorofenol
---

# 1,1'-Dimetil-4,4'-bipiridilo ión

#graphify/concept #graphify/EXTRACTED #community/paraquat__pentaclorofenol
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### paraquat → 1,1'-Dimetil-4,4'-bipiridilo ión
Relación: tiene como sinónimo · concepto conectado: [[paraquat|paraquat]]

> PARAQUAT
> 
> Sinónimos: 1,1'-Dimetil-4,4'-bipiridilo ión

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `09c351e68e0755783d9799bd367eae7f884c1d80178dd84cfc77c58eee14daae`
Localizador: {"kind": "normalized_char_offsets", "start": 320800, "end": 322680}
