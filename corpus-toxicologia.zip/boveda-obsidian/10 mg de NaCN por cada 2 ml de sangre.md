---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "testigo de sangre · 10 mg de NaCN por cada 2 ml de sangre"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/testigo_de_sangre__10_mg_de_NaCN_por_cada_2_ml_de_sangre
---

# 10 mg de NaCN por cada 2 ml de sangre

#graphify/concept #graphify/EXTRACTED #community/testigo_de_sangre__10_mg_de_NaCN_por_cada_2_ml_de_sangre
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### testigo de sangre → 10 mg de NaCN por cada 2 ml de sangre
Relación: contiene · concepto conectado: [[testigo de sangre|testigo de sangre]]

> testigo de sangre que contenga 10 mg de NaCN por cada 2 ml de sangre

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `f5ec2488a5dbd4697179229045625ed7c3900da1b4c340c5775b6f96520c17a8`
Localizador: {"kind": "normalized_char_offsets", "start": 190330, "end": 192499}
