---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "25 ml de solución de hidróxido de amonio · 0,2 ml de la muestra de sangre"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/25_ml_de_solucin_de_hidrxido_de_amonio__02_ml_de_la_muestra_de_sangre
---

# 25 ml de solución de hidróxido de amonio

#graphify/concept #graphify/EXTRACTED #community/25_ml_de_solucin_de_hidrxido_de_amonio__02_ml_de_la_muestra_de_sangre
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 0,2 ml de la muestra de sangre → 25 ml de solución de hidróxido de amonio
Relación: agregar a · concepto conectado: [[0,2 ml de la muestra de sangre|0,2 ml de la muestra de sangre]]

> Agregar 0,2 ml de la muestra de sangre a 25 ml de solución de hidróxido de amonio y mezclar.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `0fe4121ca47b30d8e7139bd3d596fd552d72605b91aa496e63665f816232766d`
Localizador: {"kind": "normalized_char_offsets", "start": 287975, "end": 289338}
