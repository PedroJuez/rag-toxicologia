---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "estricnina · diamorfina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/estricnina__diamorfina
---

# 6-acetilmorfina

#graphify/concept #graphify/EXTRACTED #community/estricnina__diamorfina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### diamorfina → 6-acetilmorfina
Relación: se hidroliza rápidamente in vivo a · concepto conectado: [[diamorfina|diamorfina]]

> La diamorfina se hidroliza rápidamente in vivo a 6-acetilmorfina

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `18b51a20dbd287e58db0b08d552772b688745473375370ead6f0edf76d9ee993`
Localizador: {"kind": "normalized_char_offsets", "start": 294014, "end": 296174}
