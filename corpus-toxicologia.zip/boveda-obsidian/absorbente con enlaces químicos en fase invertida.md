---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "absorbente con enlaces químicos en fase invertida · sílice modificada"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/absorbente_con_enlaces_qumicos_en_fase_invertida__slice_modificada
---

# absorbente con enlaces químicos en fase invertida

## Connections
- [[sílice modificada]] - `es` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/absorbente_con_enlaces_qumicos_en_fase_invertida__slice_modificada
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### absorbente con enlaces químicos en fase invertida → sílice modificada
Relación: es · concepto conectado: [[sílice modificada|sílice modificada]]

> absorbente con enlaces químicos en fase invertida (sílice modificada)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `203592cccc96c3cf217db325edf2817f8824f1444a30c7570827b0e9d294a4c1`
Localizador: {"kind": "normalized_char_offsets", "start": 114129, "end": 116384}
