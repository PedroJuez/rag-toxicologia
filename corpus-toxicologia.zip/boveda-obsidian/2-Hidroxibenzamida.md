---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "ÁCIDO SALICÍLICO · ácido acetilsalicílico"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/CIDO_SALICLICO__cido_acetilsaliclico
---

# 2-Hidroxibenzamida

#graphify/concept #graphify/EXTRACTED #community/CIDO_SALICLICO__cido_acetilsaliclico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### salicilamida → 2-Hidroxibenzamida
Relación: tiene como sinónimo · concepto conectado: [[salicilamida|salicilamida]]

> Sinónimo. 2-Hidroxibenzamida Fórmula: C₇H₇NO₂ Peso molecular: 137 N o CAS: 65–45–2 pKa= 8,2 (37°C). **Estructura Química**

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `982d058d3c39e6c1a7e3bedacea264b3b8cb4b9deb62498f3d7b26c6021c7cee`
Localizador: {"kind": "normalized_char_offsets", "start": 84662, "end": 87060}
