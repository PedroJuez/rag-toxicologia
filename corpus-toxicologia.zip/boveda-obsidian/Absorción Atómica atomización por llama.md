---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Absorción Atómica: atomización por llama · Cobre"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Absorcin_Atmica_atomizacin_por_llama__Cobre
---

# Absorción Atómica: atomización por llama

#graphify/concept #graphify/EXTRACTED #community/Absorcin_Atmica_atomizacin_por_llama__Cobre
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Cobre → Absorción Atómica: atomización por llama
Relación: se determina mediante · concepto conectado: [[Cobre|Cobre]]

> |Cobre|-Suero o plasma heparinizado en tubo plástico tratado con ác nítrico al 50% y bien enjuagado y tapón plástico. Vol. mínimo: 2 ml Enviar refrigerada 4 ºC|15 días Freezer: indefinida|El suero o plasma no deben estar hemolizados. Si se recibe sangre entera separar el plasma del paquete globular de inmediato|-Absorción Atómica: atomización por llama|

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `125515fc76e8dfe261449872350b718e3e22352a389eaabf34700879f9ed8420`
Localizador: {"kind": "normalized_char_offsets", "start": 366495, "end": 368850}
