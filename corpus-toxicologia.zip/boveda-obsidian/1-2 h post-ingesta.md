---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "Los efectos · 1-2 h post-ingesta"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Los_efectos__1-2_h_post-ingesta
---

# 1-2 h post-ingesta

#graphify/concept #graphify/EXTRACTED #community/Los_efectos__1-2_h_post-ingesta
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Los efectos → 1-2 h post-ingesta
Relación: se inician en · concepto conectado: [[Los efectos|Los efectos]]

> Los efectos se inician en 1-2 h post-ingesta

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `dbb02c729b1435b85b6c4de85062ce0d42411d631e3e89ed10ca3d14fc345092`
Localizador: {"kind": "normalized_char_offsets", "start": 285780, "end": 287769}
