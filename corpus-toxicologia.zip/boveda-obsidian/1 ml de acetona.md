---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "1 ml de acetona · 9 - carboxi-THC"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_ml_de_acetona__9_-_carboxi-THC
---

# 1 ml de acetona

#graphify/concept #graphify/EXTRACTED #community/1_ml_de_acetona__9_-_carboxi-THC
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 9 - carboxi-THC → 1 ml de acetona
Relación: se eluye con · concepto conectado: [[9 - carboxi-THC|9 - carboxi-THC]]

> Se eluye 9 - carboxi-THC con 1 ml de acetona

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `203592cccc96c3cf217db325edf2817f8824f1444a30c7570827b0e9d294a4c1`
Localizador: {"kind": "normalized_char_offsets", "start": 114129, "end": 116384}
