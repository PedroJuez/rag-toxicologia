---
source_file: "aa9042824a76474e04b695f550d4a1a7f6a031bab9025e002d4bda99fe4c46ee.md"
type: "concept"
community: "abscesos abiertos · hisopo"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abscesos_abiertos__hisopo
---

# abscesos abiertos

## Connections
- [[hisopo]] - `la muestra se tomará con` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/abscesos_abiertos__hisopo
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### abscesos abiertos → hisopo
Relación: la muestra se tomará con · concepto conectado: [[hisopo|hisopo]]

> En los abscesos abiertos la muestra se tomará con hisopo.

Fuente: Orden Ministerial 13 de Mayo Recogida de muestras.pdf
Fragmento: `7e50961cfebced7982ac16cbe33569e1c5c1577a306664ee913e480e10f42783`
Localizador: {"kind": "normalized_char_offsets", "start": 62825, "end": 64776}
