---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "KETAMINA · Metoxetamina"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/KETAMINA__Metoxetamina
---

# (R, S) -2- (O-clorofenil)-2-metilaminociclohexan-1-ona

#graphify/concept #graphify/EXTRACTED #community/KETAMINA__Metoxetamina
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### KETAMINA → (R, S) -2- (O-clorofenil)-2-metilaminociclohexan-1-ona
Relación: es · concepto conectado: [[KETAMINA|KETAMINA]]

> La ketamina es la (R, S) -2- (O-clorofenil)-2-metilaminociclohexan-1-ona.

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `a4a0ab4f6922a6414c84deff018ec96519bd83bb8ba78f7172618028d7d7b0a3`
Localizador: {"kind": "normalized_char_offsets", "start": 256377, "end": 258691}
