---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "1 UPE · 7mg Δ⁹-THC"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_UPE__7mg_-THC
---

# 7mg Δ⁹-THC

#graphify/concept #graphify/EXTRACTED #community/1_UPE__7mg_-THC
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1 UPE → 7mg Δ⁹-THC
Relación: ≈ · concepto conectado: [[1 UPE|1 UPE]]

> 1 UPE = 1 porro ≈ 0,25 gr (indistintamente de hashish o marihuana) ≈ 7mg Δ⁹-THC

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `0422e6be2e3627e95096c44d8c72ce8a7fd2d4febee7aa330e2a0306e8b73fa2`
Localizador: {"kind": "normalized_char_offsets", "start": 154317, "end": 156649}
