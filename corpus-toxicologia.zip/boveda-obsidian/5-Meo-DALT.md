---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "5-Meo-DALT · Lucy-N-Nate"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/5-Meo-DALT__Lucy-N-Nate
---

# 5-Meo-DALT

## Connections
- [[Lucy-N-Nate]] - `tiene como argot` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/5-Meo-DALT__Lucy-N-Nate
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 5-Meo-DALT → Lucy-N-Nate
Relación: tiene como argot · concepto conectado: [[Lucy-N-Nate|Lucy-N-Nate]]

> 5-Meo-DALT: *Lucy-N-Nate*

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `adf7eb817a5a36abd14d930102a077b2c1be628f7d748d60374cdf763b1f04f6`
Localizador: {"kind": "normalized_char_offsets", "start": 298205, "end": 300591}
