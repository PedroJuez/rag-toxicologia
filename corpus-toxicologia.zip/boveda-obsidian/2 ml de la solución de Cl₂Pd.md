---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "compartimento interno · 2 ml de la solución de Cl₂Pd"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/compartimento_interno__2_ml_de_la_solucin_de_ClPd
---

# 2 ml de la solución de Cl₂Pd

#graphify/concept #graphify/EXTRACTED #community/compartimento_interno__2_ml_de_la_solucin_de_ClPd
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### compartimento interno → 2 ml de la solución de Cl₂Pd
Relación: recibe la colocación de · concepto conectado: [[compartimento interno|compartimento interno]]

> En una cámara Conway colocar en el compartimento interno 2 ml de la solución de Cl₂Pd.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `bb205503edba348dbc64e46737cd7ea99745a1e828453534c552bc232dddf6b2`
Localizador: {"kind": "normalized_char_offsets", "start": 291614, "end": 294014}
