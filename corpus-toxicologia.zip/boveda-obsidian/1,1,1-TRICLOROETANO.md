---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "tetracloroetileno · ácido tricloroacético"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/tetracloroetileno__cido_tricloroactico
---

# 1,1,1-TRICLOROETANO

## Connections
- [[2,2,2-tricloroetanol]] - `se metaboliza a` [EXTRACTED]
- [[Metilcloroformo]] - `tiene como sinónimo` [EXTRACTED]
- [[limpieza en seco y vapor desengrasante]] - `es usado como solvente para` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/tetracloroetileno__cido_tricloroactico
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 1,1,1-TRICLOROETANO → Metilcloroformo
Relación: tiene como sinónimo · concepto conectado: [[Metilcloroformo|Metilcloroformo]]

> 1,1,1-TRICLOROETANO
> 
> Sinónimos: Metilcloroformo

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6a244cfdcddb27609d66e935c25470d0d170e81ee247a115730bf93326e0a849`
Localizador: {"kind": "normalized_char_offsets", "start": 346162, "end": 348152}

### 1,1,1-TRICLOROETANO → limpieza en seco y vapor desengrasante
Relación: es usado como solvente para · concepto conectado: [[limpieza en seco y vapor desengrasante|limpieza en seco y vapor desengrasante]]

> El 1,1,1-tricloroetano es ampliamente usado como un solvente para limpieza en seco y vapor desengrasante

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6a244cfdcddb27609d66e935c25470d0d170e81ee247a115730bf93326e0a849`
Localizador: {"kind": "normalized_char_offsets", "start": 346162, "end": 348152}

### 1,1,1-TRICLOROETANO → 2,2,2-tricloroetanol
Relación: se metaboliza a · concepto conectado: [[2,2,2-tricloroetanol|2,2,2-tricloroetanol]]

> El 2% de una dosis absorbida de 1,1,1-tricloroetano se metaboliza a 2,2,2-tricloroetanol

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6a244cfdcddb27609d66e935c25470d0d170e81ee247a115730bf93326e0a849`
Localizador: {"kind": "normalized_char_offsets", "start": 346162, "end": 348152}
