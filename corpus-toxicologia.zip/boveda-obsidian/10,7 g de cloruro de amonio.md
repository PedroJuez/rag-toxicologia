---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "40 ml de amonio 5 M · 10,7 g de cloruro de amonio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/40_ml_de_amonio_5_M__107_g_de_cloruro_de_amonio
---

# 10,7 g de cloruro de amonio

## Connections
- [[40 ml de amonio 5 M]] - `se disuelve en` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/40_ml_de_amonio_5_M__107_g_de_cloruro_de_amonio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 10,7 g de cloruro de amonio → 40 ml de amonio 5 M
Relación: se disuelve en · concepto conectado: [[40 ml de amonio 5 M|40 ml de amonio 5 M]]

> Disolver 10,7 g de cloruro de amonio en 40 ml de amonio 5 M

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `6af27aa0bfb702e590bbd9b2403abe2de69fcc48aa14cb1947729335c1321a41`
Localizador: {"kind": "normalized_char_offsets", "start": 364173, "end": 366495}
