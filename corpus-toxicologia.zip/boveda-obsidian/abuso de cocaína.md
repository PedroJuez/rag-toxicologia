---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "abuso de cocaína · vía intravenosa o inhalación (aspirando)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abuso_de_cocana__va_intravenosa_o_inhalacin_aspirando
---

# abuso de cocaína

## Connections
- [[vía intravenosa o inhalación (aspirando)]] - `frecuentemente es por` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/abuso_de_cocana__va_intravenosa_o_inhalacin_aspirando
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### abuso de cocaína → vía intravenosa o inhalación (aspirando)
Relación: frecuentemente es por · concepto conectado: [[vía intravenosa o inhalación (aspirando)|vía intravenosa o inhalación (aspirando)]]

> El abuso de cocaína frecuentemente es por vía intravenosa o inhalación (aspirando)

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `a4988edaeeb42d7614496e3f806cc53ac3ba7fbc4c0a87bd55f7d865825e4c41`
Localizador: {"kind": "normalized_char_offsets", "start": 203137, "end": 205367}
