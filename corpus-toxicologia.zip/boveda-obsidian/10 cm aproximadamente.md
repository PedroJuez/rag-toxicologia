---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "recorrido óptimo · 10 cm aproximadamente"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/recorrido_ptimo__10_cm_aproximadamente
---

# 10 cm aproximadamente

#graphify/concept #graphify/EXTRACTED #community/recorrido_ptimo__10_cm_aproximadamente
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### recorrido óptimo → 10 cm aproximadamente
Relación: es de · concepto conectado: [[recorrido óptimo|recorrido óptimo]]

> El recorrido óptimo es de 10 cm aproximadamente.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `3fb3de7448374fff14397300c3dc493f5a3bf31f1920153727f6c104102b995f`
Localizador: {"kind": "normalized_char_offsets", "start": 118657, "end": 120696}
