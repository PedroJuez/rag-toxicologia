---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "Cannabis · Cannabis Indica"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Cannabis__Cannabis_Indica
---

# 11-nor-9-COOH-∆ 9 -tetrahydrocannabinol

## Connections
- [[Cannabis]] - `es metabolito principal de` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/Cannabis__Cannabis_Indica
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 11-nor-9-COOH-∆ 9 -tetrahydrocannabinol → Cannabis
Relación: es metabolito principal de · concepto conectado: [[Cannabis|Cannabis]]

> quantitative analysis of the major Cannabis metabolite (11-nor-9-COOH-∆ 9 -tetrahydrocannabinol)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `0cd1f48b5b1f25760df712d56472063653edf08f61127750b1ea3295ce43ca9b`
Localizador: {"kind": "normalized_char_offsets", "start": 216060, "end": 218332}
