---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "monóxido de carbono · Ditionito de sodio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/monxido_de_carbono__Ditionito_de_sodio
---

# absorbancia relativamente alta en la región 580-600 nm

#graphify/concept #graphify/EXTRACTED #community/monxido_de_carbono__Ditionito_de_sodio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### metahemoglobina → absorbancia relativamente alta en la región 580-600 nm
Relación: tiene · concepto conectado: [[metahemoglobina|metahemoglobina]]

> metahemoglobina (que tiene una absorbancia relativamente alta en la región 580-600 nm

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `aa7c4307c5beaa7de35a737c81be3a8069bfdbe40ec558af649832e19c4be13c`
Localizador: {"kind": "normalized_char_offsets", "start": 289338, "end": 291614}
