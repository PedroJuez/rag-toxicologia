---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "0,2 µg/ml · concentraciones correspondientes de droga en el plasma"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/02_g/ml__concentraciones_correspondientes_de_droga_en_el_plasma
---

# 0,2 µg/ml

#graphify/concept #graphify/EXTRACTED #community/02_g/ml__concentraciones_correspondientes_de_droga_en_el_plasma
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### concentraciones correspondientes de droga en el plasma → 0,2 µg/ml
Relación: son inferiores a (en cuanto a la PMA) · concepto conectado: [[concentraciones correspondientes de droga en el plasma|concentraciones correspondientes de droga en el plasma]]

> En cuanto a la PMA, las concentraciones correspondientes de droga en el plasma y la orina son inferiores a 0,2 µg/ml y 5 µg/ml, respectivamente

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `b01c48c25795d720afbe34884fcae0ed76521e05b2c84e516ba9b197d01542c6`
Localizador: {"kind": "normalized_char_offsets", "start": 204471, "end": 206680}
