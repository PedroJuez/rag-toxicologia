---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "CLAR · lidocaína"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/CLAR__lidocana
---

# 2-dietilaminoacetato-2',6'-xilidida

#graphify/concept #graphify/EXTRACTED #community/CLAR__lidocana
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### lidocaína → 2-dietilaminoacetato-2',6'-xilidida
Relación: tiene como sinónimo a · concepto conectado: [[lidocaína|lidocaína]]

> Sinónimos: Lignocaina; 2-dietilaminoacetato-2',6'-xilidida.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `a1000a7529e0bd14cb86ce83afd280120c82631289d67e9c77ea26066a0f555c`
Localizador: {"kind": "normalized_char_offsets", "start": 261353, "end": 263619}
