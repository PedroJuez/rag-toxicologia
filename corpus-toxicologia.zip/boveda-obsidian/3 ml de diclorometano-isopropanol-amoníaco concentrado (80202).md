---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "Gas portador · cromatografía de gases (GC)"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Gas_portador__cromatografa_de_gases_GC
---

# 3 ml de diclorometano-isopropanol-amoníaco concentrado (80:20:2)

#graphify/concept #graphify/EXTRACTED #community/Gas_portador__cromatografa_de_gases_GC
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### analitos → 3 ml de diclorometano-isopropanol-amoníaco concentrado (80:20:2)
Relación: se eluyen con · concepto conectado: [[analitos|analitos]]

> los analitos se eluyen con 3 ml de diclorometano-isopropanol-amoníaco concentrado (80:20:2)

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `f94e3c69fe8599040d5a16ad06484a398038f8d089d99d4160318f0ad8167379`
Localizador: {"kind": "normalized_char_offsets", "start": 73934, "end": 76305}
