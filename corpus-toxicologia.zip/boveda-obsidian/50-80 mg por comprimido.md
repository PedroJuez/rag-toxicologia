---
source_file: "e6cfc2cc2d1f5ad6a38712dbbec0d9186dfd09825f93bebaf868d75651a0f2d1.md"
type: "concept"
community: "La dosis habitual · 50-80 mg por comprimido"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/La_dosis_habitual__50-80_mg_por_comprimido
---

# 50-80 mg por comprimido

#graphify/concept #graphify/EXTRACTED #community/La_dosis_habitual__50-80_mg_por_comprimido
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### La dosis habitual → 50-80 mg por comprimido
Relación: es de · concepto conectado: [[La dosis habitual|La dosis habitual]]

> La dosis habitual es de 50-80 mg por comprimido

Fuente: Libro_Drogas_de_abuso_en_toxicologia_23_03_20.pdf
Fragmento: `6fa015ced0db15486700a8257803871472be59e75dc3303df215509fd55594c9`
Localizador: {"kind": "normalized_char_offsets", "start": 198686, "end": 200965}
