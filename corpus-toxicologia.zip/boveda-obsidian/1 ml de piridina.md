---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "1 ml de piridina · 40 ml de una solución de sulfato de cobre al 10%"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/1_ml_de_piridina__40_ml_de_una_solucin_de_sulfato_de_cobre_al_10
---

# 1 ml de piridina

#graphify/concept #graphify/EXTRACTED #community/1_ml_de_piridina__40_ml_de_una_solucin_de_sulfato_de_cobre_al_10
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 40 ml de una solución de sulfato de cobre al 10% → 1 ml de piridina
Relación: se mezclan con · concepto conectado: [[40 ml de una solución de sulfato de cobre al 10%|40 ml de una solución de sulfato de cobre al 10%]]

> Mezclar 40 ml de una solución de sulfato de cobre al 10% con 1 ml de piridina y agregar agua suficiente para 100 ml.

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `2fa970fc1cad157e7be49f789f0f771ac141d6452f73a78826421786876b30ab`
Localizador: {"kind": "normalized_char_offsets", "start": 361850, "end": 364173}
