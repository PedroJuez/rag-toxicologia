---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "3,4-metilendioximetanfetamina · MDMA, éxtasis"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/34-metilendioximetanfetamina__MDMA_xtasis
---

# 3,4-metilendioximetanfetamina

## Connections
- [[MDMA, éxtasis]] - `es abreviado o conocido como` [EXTRACTED]

#graphify/concept #graphify/EXTRACTED #community/34-metilendioximetanfetamina__MDMA_xtasis
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### 3,4-metilendioximetanfetamina → MDMA, éxtasis
Relación: es abreviado o conocido como · concepto conectado: [[MDMA, éxtasis|MDMA, éxtasis]]

> |3,4-metilendioximetanfetamina|MDMA, éxtasis|

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `a16d7facd34189e42dbfdaf6b471a247f3ad3bd5502b14c7d9e2fb83927f4155`
Localizador: {"kind": "normalized_char_offsets", "start": 184277, "end": 186281}
