---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "técnica de inmunoanálisis enzimático para pruebas múltiples (EMIT) · 300 ng/ml"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/tcnica_de_inmunoanlisis_enzimtico_para_pruebas_mltiples_EMIT__300_ng/ml
---

# 300 ng/ml

#graphify/concept #graphify/EXTRACTED #community/tcnica_de_inmunoanlisis_enzimtico_para_pruebas_mltiples_EMIT__300_ng/ml
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### técnica de inmunoanálisis enzimático para pruebas múltiples (EMIT) → 300 ng/ml
Relación: tiene límites de detección de · concepto conectado: [[técnica de inmunoanálisis enzimático para pruebas múltiples (EMIT)|técnica de inmunoanálisis enzimático para pruebas múltiples (EMIT)]]

> mientras que con la técnica de inmunoanálisis enzimático para pruebas múltiples (EMIT) son de 300 ng/ml.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `4ee068b6f8ea95fdc833474af09a56db1a3e56613d9da9edee64d5524a7f6ffe`
Localizador: {"kind": "normalized_char_offsets", "start": 142293, "end": 144575}
