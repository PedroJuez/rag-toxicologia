---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "niveles de MDA en el plasma · 5 a 25 µg/ml"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/niveles_de_MDA_en_el_plasma__5_a_25_g/ml
---

# 5 a 25 µg/ml

#graphify/concept #graphify/EXTRACTED #community/niveles_de_MDA_en_el_plasma__5_a_25_g/ml
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### niveles de MDA en el plasma → 5 a 25 µg/ml
Relación: se han hallado en caso de consumo excesivo · concepto conectado: [[niveles de MDA en el plasma|niveles de MDA en el plasma]]

> En caso de consumo excesivo, se han hallado en el plasma y la orina niveles de MDA de 5 a 25 µg/ml y 50 a 150 µg/ml, respectivamente.

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `b01c48c25795d720afbe34884fcae0ed76521e05b2c84e516ba9b197d01542c6`
Localizador: {"kind": "normalized_char_offsets", "start": 204471, "end": 206680}
