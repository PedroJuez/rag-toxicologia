---
source_file: "8782069ece17f00490d8b0d15d71cdf79ebdc79b61c2b96f1104c6d786b30d93.md"
type: "concept"
community: "Nicotina · vapores de mercurio"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/Nicotina__vapores_de_mercurio
---

# 3-(1-Metilpirrolidina-2-il)piridina

#graphify/concept #graphify/EXTRACTED #community/Nicotina__vapores_de_mercurio
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### Nicotina → 3-(1-Metilpirrolidina-2-il)piridina
Relación: tiene sinónimo · concepto conectado: [[Nicotina|Nicotina]]

> NICOTINA
> 
> Sinónimos: 3-(1-Metilpirrolidina-2-il)piridina

Fuente: toxicologia_libro_analitica.pdf
Fragmento: `a4f8c1153bf8126ec95c7b088f6c8673849d624385fccb7187866de3b6640654`
Localizador: {"kind": "normalized_char_offsets", "start": 296174, "end": 298082}
