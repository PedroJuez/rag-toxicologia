---
source_file: "aa9042824a76474e04b695f550d4a1a7f6a031bab9025e002d4bda99fe4c46ee.md"
type: "concept"
community: "abierto · El útero"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/abierto__El_tero
---

# abierto

#graphify/concept #graphify/EXTRACTED #community/abierto__El_tero
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### El útero → abierto
Relación: se enviará · concepto conectado: [[El útero|El útero]]

> El útero se enviará abierto

Fuente: Orden Ministerial 13 de Mayo Recogida de muestras.pdf
Fragmento: `79621693a0ec1824489de1385c263f5e1bcc456b5c04b75fa6c5c50ac6c39b75`
Localizador: {"kind": "normalized_char_offsets", "start": 22386, "end": 24786}
