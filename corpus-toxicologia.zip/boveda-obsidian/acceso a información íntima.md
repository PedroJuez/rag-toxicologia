---
source_file: "d115aa88b694132d06236fc4806abbaecdf1b8b0184ed267d43c7dd39eb70fe6.md"
type: "concept"
community: "El Tribunal · La suspensión"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/El_Tribunal__La_suspensin
---

# acceso a información íntima

#graphify/concept #graphify/EXTRACTED #community/El_Tribunal__La_suspensin
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### El Tribunal → acceso a información íntima
Relación: distinguió la extracción corporal de · concepto conectado: [[El Tribunal|El Tribunal]]

> El Tribunal distinguió la extracción corporal del acceso a información íntima.

Fuente: toxicologia-derecho-penal-espana-2026-09-14.md
Fragmento: `16318024f308109fa41b3fad4bbbcaa4dcbbe00197f6a94fc338b36fcc20f6ad`
Localizador: {"kind": "normalized_char_offsets", "start": 36253, "end": 38462}
