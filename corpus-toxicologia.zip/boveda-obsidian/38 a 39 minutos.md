---
source_file: "325f15fe608125333fc9e9f6ea26e0af3f500aecfc493ac6c5b1cc4ee84f058a.md"
type: "concept"
community: "período medio de eliminación de la cocaína del plasma tras su administración por vía intravenosa o intrapulmonar · 38 a 39 minutos"
tags:
  - graphify/concept
  - graphify/EXTRACTED
  - community/perodo_medio_de_eliminacin_de_la_cocana_del_plasma_tras_su_administracin_por_va_intravenosa_o_intrapulmonar__38_a_39_minutos
---

# 38 a 39 minutos

#graphify/concept #graphify/EXTRACTED #community/perodo_medio_de_eliminacin_de_la_cocana_del_plasma_tras_su_administracin_por_va_intravenosa_o_intrapulmonar__38_a_39_minutos
## Evidencias del piloto

Las citas son afirmaciones de los documentos, no validación científica. Se incluyen relaciones entrantes y salientes.

### período medio de eliminación de la cocaína del plasma tras su administración por vía intravenosa o intrapulmonar → 38 a 39 minutos
Relación: es de · concepto conectado: [[período medio de eliminación de la cocaína del plasma tras su administración por vía intravenosa o intrapulmonar|período medio de eliminación de la cocaína del plasma tras su administración por vía intravenosa o intrapulmonar]]

> El período medio de eliminación de la cocaína del plasma tras su administración por vía intravenosa o intrapulmonar es de 38 a 39 minutos

Fuente: deteccionyanalisisdrogas.pdf
Fragmento: `628eb130f6bf2cf9ad8b3291b875bcb00961b4ca4cf113fabc1d99bbc63cfb2e`
Localizador: {"kind": "normalized_char_offsets", "start": 133254, "end": 135626}
